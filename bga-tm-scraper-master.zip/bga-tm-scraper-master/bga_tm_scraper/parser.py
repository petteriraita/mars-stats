"""
Terraforming Mars game log parser for BoardGameArena replays
Comprehensive parser that extracts all game data into a structured format
"""
import re
import json
import os
from typing import List, Dict, Optional, Any, Tuple
from dataclasses import dataclass, asdict, replace
from datetime import datetime, timedelta
from bs4 import BeautifulSoup, Tag
import logging

logger = logging.getLogger(__name__)

@dataclass
class EloData:
    """Represents ELO information for a player"""
    arena_points: Optional[int] = None
    arena_points_change: Optional[int] = None
    game_rank: Optional[int] = None
    game_rank_change: Optional[int] = None
    player_name: Optional[str] = None
    player_id: Optional[str] = None
    position: Optional[int] = None

@dataclass
class GameMetadata:
    """Represents metadata from table HTML or assignment for replay scraping"""
    played_at: Optional[str] = None  # ISO timestamp when game was played
    map: Optional[str] = None
    prelude_on: Optional[bool] = None
    colonies_on: Optional[bool] = None
    corporate_era_on: Optional[bool] = None
    draft_on: Optional[bool] = None
    beginners_corporations_on: Optional[bool] = None
    game_speed: Optional[str] = None
    game_mode: Optional[str] = None
    version_id: Optional[str] = None
    players: Optional[Dict[str, EloData]] = None  # player_id -> EloData

@dataclass
class GameState:
    """Represents the game state at a specific point in time"""
    move_number: int
    generation: int
    temperature: int
    oxygen: int
    oceans: int
    player_vp: Dict[str, Dict[str, Any]]  # player_id -> VP breakdown
    milestones: Dict[str, Dict[str, Any]]  # milestone_name -> details
    awards: Dict[str, Dict[str, Any]]  # award_name -> details
    player_trackers: Dict[str, Dict[str, int]] = None  # player_id -> tracker_name -> value
    special_tiles: Dict[str, Dict[str, str]] = None  # player_id -> {card_name: hex_location}
    starting_player: Optional[str] = None  # player_id of the starting player this generation
    player_hands: Dict[str, List[str]] = None  # player_id -> list of card names in hand
    draw_pile: Optional[int] = None
    discard_pile: Optional[int] = None

    def __post_init__(self):
        if self.player_vp is None:
            self.player_vp = {}
        if self.milestones is None:
            self.milestones = {}
        if self.awards is None:
            self.awards = {}
        if self.player_trackers is None:
            self.player_trackers = {}
        if self.special_tiles is None:
            self.special_tiles = {}
        if self.player_hands is None:
            self.player_hands = {}

@dataclass
class Move:
    """Represents a single move in the game"""
    move_number: int
    timestamp: str
    player_id: str
    player_name: str
    action_type: str
    description: str
    
    # Detailed action data
    card_played: Optional[str] = None
    card_drafted: Optional[str] = None
    tile_placed: Optional[str] = None
    tile_location: Optional[str] = None
    card_options: Optional[Dict[str, List[str]]] = None
    cards_kept: Optional[Dict[str, List[str]]] = None
    cards_discarded: Optional[List[str]] = None
    draft_passed_to: Optional[Dict[str, str]] = None  # internal; promoted to GameData.draft_directions
    reason: Optional[str] = None

    # Game state after this move
    game_state: Optional[GameState] = None

@dataclass
class StartingHand:
    """Represents the hand for a player"""
    corporations: List[str]
    preludes: List[str]
    project_cards: List[str]

@dataclass
class Player:
    """Represents a player in the game"""
    player_id: str
    player_name: str
    corporation: str
    final_vp: int
    final_tr: int
    vp_breakdown: Dict[str, Any]
    cards_played: List[str]
    milestones_claimed: List[str]
    awards_funded: List[str]
    color: Optional[str] = None
    starting_hand: Optional[StartingHand] = None
    elo_data: Optional[EloData] = None

@dataclass
class GameData:
    """Complete game data structure"""
    # Game metadata
    replay_id: str
    player_perspective: str
    game_date: str
    game_duration: str
    winner: str
    generations: int
    conceded: bool = False
    map: Optional[str] = None
    prelude_on: Optional[bool] = None
    colonies_on: Optional[bool] = None
    corporate_era_on: Optional[bool] = None
    draft_on: Optional[bool] = None
    beginners_corporations_on: Optional[bool] = None
    game_speed: Optional[str] = None
    draft_directions: Optional[Dict[int, Dict[str, str]]] = None  # generation -> {player_id -> player_id they pass to}

    # Players
    players: Dict[str, Player] = None  # player_id -> Player
    
    # All moves with game states
    moves: List[Move] = None

    # Analysis metadata
    metadata: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.players is None:
            self.players = {}
        if self.moves is None:
            self.moves = []
        if self.metadata is None:
            self.metadata = {}

class Parser:
    """Comprehensive Terraforming Mars game log parser for BoardGameArena replays"""

    # Map option (id 107) values/short labels -> canonical map names
    MAP_VALUE_NAMES = {
        '0': 'Tharsis',
        '1': 'Elysium',
        '2': 'Hellas',
        '3': 'Vastitas Borealis',
        '4': 'Amazonis Planitia',
        'Vastitas': 'Vastitas Borealis',
        'Amazonis': 'Amazonis Planitia',
    }

    def __init__(self):
        pass
    
    def parse_table_metadata(self, table_html: str) -> GameMetadata:
        """Extract all metadata from table HTML including game mode, map, settings, and ELO data"""
        logger.info("Parsing table metadata from HTML")
        
        soup = BeautifulSoup(table_html, 'html.parser')
        
        # Extract game mode
        game_mode = self._extract_game_mode_from_table(table_html)
        
        # Extract map
        map_name = self._extract_map_from_table(table_html)
        
        # Extract game settings
        corporate_era_on = self._extract_corporate_era_from_table(table_html)
        prelude_on = self._extract_prelude_from_table(table_html)
        draft_on = self._extract_draft_from_table(table_html)
        colonies_on = self._extract_colonies_from_table(table_html)
        beginners_corporations_on = self._extract_beginners_corporations_from_table(table_html)
        game_speed = self._extract_game_speed_from_table(table_html)
        
        # Extract ELO data and convert to Dict[str, EloData] with string keys
        elo_data_dict = self.parse_elo_data(table_html)
        players_dict = {}
        for player_name, elo_data in elo_data_dict.items():
            # Ensure player_id is string
            player_id = str(elo_data.player_id) if elo_data.player_id else ""
            if player_id:
                players_dict[player_id] = elo_data
        
        metadata = GameMetadata(
            map=map_name,
            prelude_on=prelude_on,
            colonies_on=colonies_on,
            corporate_era_on=corporate_era_on,
            draft_on=draft_on,
            beginners_corporations_on=beginners_corporations_on,
            game_speed=game_speed,
            game_mode=game_mode,
            players=players_dict
        )
        
        logger.info(f"Successfully parsed table metadata: {len(players_dict)} players, game_mode={game_mode}, map={map_name}")
        return metadata
    
    def convert_assignment_to_game_metadata(self, assignment_data: Dict[str, Any]) -> GameMetadata:
        """Convert GUI assignment data (camelCase) to GameMetadata with EloData objects"""
        logger.info("Converting assignment data to GameMetadata")
        
        players_dict = {}
        for player in assignment_data.get('players', []):
            player_id = str(player.get('playerId', ''))
            if player_id:
                elo_data = EloData(
                    player_name=player.get('playerName'),
                    player_id=player_id,
                    position=player.get('position'),
                    arena_points=player.get('arenaPoints'),
                    arena_points_change=player.get('arenaPointsChange'),
                    game_rank=player.get('elo'),
                    game_rank_change=player.get('eloChange')
                )
                players_dict[player_id] = elo_data
        
        metadata = GameMetadata(
            played_at=assignment_data.get('playedAt'),
            map=assignment_data.get('map'),
            prelude_on=assignment_data.get('preludeOn'),
            colonies_on=assignment_data.get('coloniesOn'),
            corporate_era_on=assignment_data.get('corporateEraOn'),
            draft_on=assignment_data.get('draftOn'),
            beginners_corporations_on=assignment_data.get('beginnersCorporationsOn'),
            game_speed=assignment_data.get('gameSpeed'),
            game_mode=assignment_data.get('gameMode', 'Arena mode'),
            version_id=assignment_data.get('versionId'),
            players=players_dict
        )
        
        logger.info(f"Successfully converted assignment data: {len(players_dict)} players")
        return metadata
    
    def _extract_game_mode_from_table(self, table_html: str) -> str:
        """Extract game mode from table HTML"""
        soup = BeautifulSoup(table_html, 'html.parser')
        span_element = soup.find('span', id='mob_gameoption_201_displayed_value')
        
        if span_element:
            mode = span_element.get_text().strip()
            return mode
        else:
            return "Normal mode"  # Default
    
    def _extract_map_from_table(self, table_html: str) -> Optional[str]:
        """Extract the selected map from table page HTML"""
        try:
            soup = BeautifulSoup(table_html, 'html.parser')
            
            # Look for the specific map element
            map_element = soup.find('span', id='gameoption_107_displayed_value')
            
            if map_element:
                map_name = map_element.get_text().strip()
                logger.info(f"Extracted map: {map_name}")
                return map_name
            else:
                logger.debug("Map element not found in table HTML")
                return None
                
        except Exception as e:
            logger.error(f"Error extracting map from table HTML: {e}")
            return None
    
    def _extract_map_from_replay(self, replay_html: str) -> Optional[str]:
        """Extract the actual map from replay HTML Game options section.
        
        This is used when the map selection was 'Random' to find the actual map used.
        The replay HTML contains a Game options section with the resolved map name.
        """
        try:
            soup = BeautifulSoup(replay_html, 'html.parser')
            
            # Primary method: Look for the specific footer option value element
            map_element = soup.find('div', id='footer_option_value_107')
            if map_element:
                map_name = map_element.get_text().strip()
                logger.info(f"Extracted actual map from replay: {map_name}")
                return map_name
            
            # Fallback: Search for row-label "Map" and get sibling row-value
            row_labels = soup.find_all('div', class_='row-label')
            for label in row_labels:
                if label.get_text().strip() == 'Map':
                    # Find the sibling row-value
                    parent = label.find_parent('div', class_='row-data')
                    if parent:
                        value_div = parent.find('div', class_='row-value')
                        if value_div:
                            map_name = value_div.get_text().strip()
                            logger.info(f"Extracted actual map from replay (fallback): {map_name}")
                            return map_name

            # Fallback for the newer replay page format: the map is in the embedded
            # bgaGameData JSON as tableOptions entry {"id":107,"name":"Map","value":N,"valueLabel":"..."}
            # with the resolved map name even when the table selection was "Random".
            option_match = re.search(
                r'\{"id":\s*107\s*,\s*"name":\s*"Map"\s*,\s*"value":\s*(\d+)\s*(?:,\s*"valueLabel":\s*"([^"]*)")?',
                replay_html
            )
            if option_match:
                value_label = option_match.group(2)
                if value_label:
                    map_name = self.MAP_VALUE_NAMES.get(value_label, value_label)
                    logger.info(f"Extracted actual map from replay (tableOptions): {map_name}")
                    return map_name
                map_value = option_match.group(1)
                map_name = self.MAP_VALUE_NAMES.get(map_value)
                if map_name:
                    logger.info(f"Extracted actual map from replay (tableOptions value {map_value}): {map_name}")
                    return map_name

            logger.debug("Map element not found in replay HTML Game options")
            return None
            
        except Exception as e:
            logger.error(f"Error extracting map from replay HTML: {e}")
            return None
    
    def _extract_corporate_era_from_table(self, table_html: str) -> Optional[bool]:
        """Extract the Corporate Era setting from table page HTML"""
        try:
            soup = BeautifulSoup(table_html, 'html.parser')
            
            # Look for the specific Corporate Era element
            corporate_era_element = soup.find('span', id='mob_gameoption_101_displayed_value')
            
            if corporate_era_element:
                corporate_era_text = corporate_era_element.get_text().strip()
                corporate_era_on = corporate_era_text.lower() == 'on'
                logger.info(f"Extracted Corporate Era: {corporate_era_text} -> {corporate_era_on}")
                return corporate_era_on
            else:
                logger.debug("Corporate Era element not found in table HTML")
                return None
                
        except Exception as e:
            logger.error(f"Error extracting Corporate Era from table HTML: {e}")
            return None
    
    def _extract_prelude_from_table(self, table_html: str) -> Optional[bool]:
        """Extract the Prelude setting from table page HTML"""
        try:
            soup = BeautifulSoup(table_html, 'html.parser')
            
            # Look for the specific Prelude element
            prelude_element = soup.find('span', id='mob_gameoption_104_displayed_value')
            
            if prelude_element:
                prelude_text = prelude_element.get_text().strip()
                prelude_on = prelude_text.lower() == 'on'
                logger.info(f"Extracted Prelude: {prelude_text} -> {prelude_on}")
                return prelude_on
            else:
                logger.debug("Prelude element not found in table HTML")
                return None
                
        except Exception as e:
            logger.error(f"Error extracting Prelude from table HTML: {e}")
            return None
    
    def _extract_draft_from_table(self, table_html: str) -> Optional[bool]:
        """Extract the Draft setting from table page HTML"""
        try:
            soup = BeautifulSoup(table_html, 'html.parser')
            
            # Look for the specific Draft element
            draft_element = soup.find('span', id='mob_gameoption_103_displayed_value')
            
            if draft_element:
                draft_text = draft_element.get_text().strip()
                draft_on = draft_text.lower() == 'yes'
                logger.info(f"Extracted Draft: {draft_text} -> {draft_on}")
                return draft_on
            else:
                logger.debug("Draft element not found in table HTML")
                return None
                
        except Exception as e:
            logger.error(f"Error extracting Draft from table HTML: {e}")
            return None
    
    def _extract_colonies_from_table(self, table_html: str) -> Optional[bool]:
        """Extract the Colonies setting from table page HTML"""
        try:
            soup = BeautifulSoup(table_html, 'html.parser')
            
            # Look for the specific Colonies element
            colonies_element = soup.find('span', id='mob_gameoption_108_displayed_value')
            
            if colonies_element:
                colonies_text = colonies_element.get_text().strip()
                colonies_on = colonies_text.lower() == 'on'
                logger.info(f"Extracted Colonies: {colonies_text} -> {colonies_on}")
                return colonies_on
            else:
                logger.debug("Colonies element not found in table HTML")
                return None
                
        except Exception as e:
            logger.error(f"Error extracting Colonies from table HTML: {e}")
            return None
    
    def _extract_beginners_corporations_from_table(self, table_html: str) -> Optional[bool]:
        """Extract the Beginners Corporations setting from table page HTML"""
        try:
            soup = BeautifulSoup(table_html, 'html.parser')
            
            # Look for the specific Beginners Corporations element
            beginners_corps_element = soup.find('span', id='gameoption_100_displayed_value')
            
            if beginners_corps_element:
                beginners_corps_text = beginners_corps_element.get_text().strip()
                beginners_corps_on = beginners_corps_text.lower() == 'yes'
                logger.info(f"Extracted Beginners Corporations: {beginners_corps_text} -> {beginners_corps_on}")
                return beginners_corps_on
            else:
                logger.debug("Beginners Corporations element not found in table HTML")
                return None
                
        except Exception as e:
            logger.error(f"Error extracting Beginners Corporations from table HTML: {e}")
            return None
    
    def _extract_game_speed_from_table(self, table_html: str) -> Optional[str]:
        """Extract the Game Speed setting from table page HTML"""
        try:
            soup = BeautifulSoup(table_html, 'html.parser')
            
            # Look for the specific Game Speed element
            game_speed_element = soup.find('span', id='gameoption_200_displayed_value')
            
            if game_speed_element:
                game_speed_text = game_speed_element.get_text().strip()
                logger.info(f"Extracted Game Speed: {game_speed_text}")
                return game_speed_text
            else:
                logger.debug("Game Speed element not found in table HTML")
                return None
                
        except Exception as e:
            logger.error(f"Error extracting Game Speed from table HTML: {e}")
            return None

    def _extract_game_date_from_table(self, table_html: str) -> Optional[Dict]:
        """
        Extract the game creation date from table page HTML
        
        Args:
            table_html: HTML content of the table page
            
        Returns:
            dict: Dictionary with raw_datetime, parsed_datetime, and date_type, or None if not found
        """
        try:
            soup = BeautifulSoup(table_html, 'html.parser')
            
            # Look for the creationtime div
            creationtime_element = soup.find('div', id='creationtime')
            
            if creationtime_element:
                creation_text = creationtime_element.get_text().strip()
                logger.info(f"Found creation time text: {creation_text}")
                
                # Extract the date part after "Created "
                if creation_text.startswith('Created '):
                    date_text = creation_text[8:]  # Remove "Created " prefix
                    
                    # Use the existing _parse_game_datetime method to handle both relative and absolute dates
                    datetime_info = self._parse_game_datetime(date_text)
                    
                    if datetime_info:
                        logger.info(f"Successfully extracted game date from table: {datetime_info['raw_datetime']}")
                        return datetime_info
                    else:
                        logger.warning(f"Could not parse date from: {date_text}")
                else:
                    logger.warning(f"Unexpected creation time format: {creation_text}")
            else:
                logger.debug("Creation time element not found in table HTML")
            
            return None
                
        except Exception as e:
            logger.error(f"Error extracting game date from table HTML: {e}")
            return None

    def _parse_game_datetime(self, text: str) -> Optional[Dict]:
        """
        Parse datetime from text, handling both relative and absolute dates
        
        Args:
            text: Text that may contain datetime information
            
        Returns:
            dict: Dictionary with raw_datetime, parsed_datetime, and date_type, or None if not found
        """
        try:
            # Pattern 1: Relative dates like "52 minutes ago" or "1 hour ago"
            relative_ago_pattern = r'(\d+)\s+(minute|hour|day)s?\s+ago'
            relative_ago_match = re.search(relative_ago_pattern, text.lower())

            if relative_ago_match:
                value = int(relative_ago_match.group(1))
                unit = relative_ago_match.group(2)
                
                delta = timedelta()
                if unit == 'minute':
                    delta = timedelta(minutes=value)
                elif unit == 'hour':
                    delta = timedelta(hours=value)
                elif unit == 'day':
                    delta = timedelta(days=value)
                
                parsed_datetime = datetime.now() - delta
                
                return {
                    'raw_datetime': text,
                    'parsed_datetime': parsed_datetime.isoformat(),
                    'date_type': 'relative_ago'
                }

            # Pattern 2: Relative dates like "yesterday at 00:08"
            relative_pattern = r'(yesterday|today)\s+at\s+(\d{1,2}:\d{2})'
            relative_match = re.search(relative_pattern, text.lower())
            
            if relative_match:
                relative_word = relative_match.group(1)
                time_str = relative_match.group(2)
                
                # Calculate the actual date
                current_date = datetime.now()
                if relative_word == 'yesterday':
                    target_date = current_date - timedelta(days=1)
                else:  # today
                    target_date = current_date
                
                # Parse the time
                time_parts = time_str.split(':')
                hour = int(time_parts[0])
                minute = int(time_parts[1])
                
                # Create the full datetime
                parsed_datetime = target_date.replace(hour=hour, minute=minute, second=0, microsecond=0)
                
                return {
                    'raw_datetime': f"{relative_word} at {time_str}",
                    'parsed_datetime': parsed_datetime.isoformat(),
                    'date_type': 'relative'
                }
            
            # Pattern 3: Absolute dates like "2025-06-15 at 00:29"
            absolute_pattern = r'(\d{4}-\d{2}-\d{2})\s+at\s+(\d{1,2}:\d{2})'
            absolute_match = re.search(absolute_pattern, text)
            
            if absolute_match:
                date_str = absolute_match.group(1)
                time_str = absolute_match.group(2)
                
                # Parse the full datetime
                datetime_str = f"{date_str} {time_str}:00"
                parsed_datetime = datetime.strptime(datetime_str, "%Y-%m-%d %H:%M:%S")
                
                return {
                    'raw_datetime': f"{date_str} at {time_str}",
                    'parsed_datetime': parsed_datetime.isoformat(),
                    'date_type': 'absolute'
                }
            
            # Pattern 4: Alternative absolute format like "15/06/2025 at 00:29"
            alt_absolute_pattern = r'(\d{1,2}/\d{1,2}/\d{4})\s+at\s+(\d{1,2}:\d{2})'
            alt_absolute_match = re.search(alt_absolute_pattern, text)
            
            if alt_absolute_match:
                date_str = alt_absolute_match.group(1)
                time_str = alt_absolute_match.group(2)
                
                # Parse the date (assuming DD/MM/YYYY format)
                date_parts = date_str.split('/')
                day = int(date_parts[0])
                month = int(date_parts[1])
                year = int(date_parts[2])
                
                # Parse the time
                time_parts = time_str.split(':')
                hour = int(time_parts[0])
                minute = int(time_parts[1])
                
                # Create the datetime
                parsed_datetime = datetime(year, month, day, hour, minute, 0)
                
                return {
                    'raw_datetime': f"{date_str} at {time_str}",
                    'parsed_datetime': parsed_datetime.isoformat(),
                    'date_type': 'absolute'
                }
            
            # Pattern 5: Just time like "00:08" (assume today)
            time_only_pattern = r'\b(\d{1,2}:\d{2})\b'
            time_only_match = re.search(time_only_pattern, text)
            
            if time_only_match:
                time_str = time_only_match.group(1)
                
                # Parse the time and assume today
                time_parts = time_str.split(':')
                hour = int(time_parts[0])
                minute = int(time_parts[1])
                
                current_date = datetime.now()
                parsed_datetime = current_date.replace(hour=hour, minute=minute, second=0, microsecond=0)
                
                return {
                    'raw_datetime': time_str,
                    'parsed_datetime': parsed_datetime.isoformat(),
                    'date_type': 'time_only'
                }
            
            return None
            
        except Exception as e:
            logger.debug(f"Error parsing datetime from text '{text}': {e}")
            return None
    
    def parse_complete_game(self, replay_html: str, game_metadata: GameMetadata, table_id: str, player_perspective: str) -> GameData:
        """Unified parsing method that takes GameMetadata instead of separate parameters"""
        logger.info(f"Starting unified parsing for game {table_id}")
        
        soup = BeautifulSoup(replay_html, 'html.parser')
        
        # If map is missing or "Random", extract the actual map from the replay HTML
        if not game_metadata.map or game_metadata.map.lower() == 'random':
            actual_map = self._extract_map_from_replay(replay_html)
            if actual_map:
                logger.info(f"Resolved map from replay HTML: {actual_map}")
                game_metadata.map = actual_map
            elif not game_metadata.map:
                logger.warning("Could not extract map from replay HTML")
        
        # Extract gamelogs once for memory efficiency
        gamelogs = self._extract_g_gamelogs(replay_html)
        
        # Extract player IDs from GameMetadata
        player_id_map = self._get_player_id_map(game_metadata)

        # Build token_types early (needed for VP progression and name mappings)
        token_types = self._extract_token_types(replay_html)

        # Extract VP progression throughout the game
        vp_progression = self._extract_vp_progression(replay_html, gamelogs, token_types)

        # Create simple name_to_id mapping for move processing
        name_to_id = {name: player_id for player_id, name in player_id_map.items()}

        # Extract corporations from HTML, with gamelogs fallback
        corporations = self._extract_corporations(soup, player_perspective, player_id_map)
        if not corporations and gamelogs:
            try:
                for entry in gamelogs.get('data', {}).get('data', []):
                    if not isinstance(entry, dict):
                        continue
                    for item in entry.get('data', []):
                        if not isinstance(item, dict):
                            continue
                        log = item.get('log', '')
                        if 'chooses corporation' not in log:
                            continue
                        args = item.get('args', {}) or {}
                        if not isinstance(args, dict):
                            continue
                        player_name = args.get('player_name')
                        token_id = args.get('token_id', '')
                        if isinstance(player_name, str) and isinstance(token_id, str) and token_id.startswith('card_corp_'):
                            corp_name = token_types.get(token_id, {}).get('name') if token_types else None
                            if corp_name:
                                corporations[player_name] = corp_name
                                logger.info(f"Extracted corporation from gamelogs: {player_name} -> {corp_name}")
            except Exception:
                pass
        card_names_map = self._extract_card_names_from_token_types(token_types)
        # Also include standard project, colony, tile, and hex names for description rendering
        tile_base_names: Dict[str, str] = {}
        for token_id, token_data in token_types.items():
            if token_id not in card_names_map and isinstance(token_data, dict):
                if token_id.startswith(('card_stanproj_', 'card_colo_', 'tile_', 'hex_', 'milestone_', 'award_')):
                    name = token_data.get('name') or token_data.get('tooltip_action')
                    if isinstance(name, str) and name.strip():
                        card_names_map[token_id] = name.strip()
                        if token_id.startswith('tile_'):
                            tile_base_names[token_id] = name.strip()
        # Map tile instance IDs (e.g. tile_2_1) to their base name (tile_2 -> City)
        # by scanning gamelogs for all tile tokens placed
        if gamelogs and tile_base_names:
            for entry in gamelogs.get('data', {}).get('data', []):
                for item in entry.get('data', []):
                    if isinstance(item, dict) and item.get('type') == 'tokenMoved':
                        tid = (item.get('args') or {}).get('token_id', '')
                        if isinstance(tid, str) and tid.startswith('tile_') and tid not in card_names_map:
                            tile_base = re.sub(r'_\d+$', '', tid)
                            if tile_base in tile_base_names:
                                card_names_map[tid] = tile_base_names[tile_base]

        # Extract tracker dictionary dynamically from HTML
        tracker_dict = self._extract_tracker_dictionary_from_html(replay_html)

        # Build color -> player_id mapping from HTML
        color_to_player_id = {}
        player_id_to_color = {}
        for color_match in re.finditer(r'id="player_area_name_([0-9a-fA-F]{6})"[^>]*>([^<]+)<', replay_html):
            color = color_match.group(1).lower()
            pname = color_match.group(2).strip()
            pid = name_to_id.get(pname)
            if pid:
                color_to_player_id[color] = int(pid)
                player_id_to_color[pid] = f"#{color}"
        logger.info(f"Color to player mapping: {color_to_player_id}")

        # Enrich tracker_dict with token_types × player colors so descriptions
        # render correctly (e.g. tracker_m_ff0000 → "M€" instead of "Unknown")
        for tt_key, tt_val in token_types.items():
            if isinstance(tt_val, dict) and tt_key.startswith('tracker_') and 'name' in tt_val:
                if not re.search(r'_[0-9a-fA-F]{6}$', tt_key):
                    tracker_dict[tt_key] = tt_val['name']
                    for color in color_to_player_id:
                        tracker_dict[f"{tt_key}_{color}"] = tt_val['name']

        # Extract all moves with detailed parsing (using simple name mapping and tracker dict)
        moves = self._extract_all_moves_simple(soup, name_to_id, gamelogs, card_names_map, tracker_dict)
        
        # Build game states for each move
        moves_with_states = self._build_game_states_simple(moves, vp_progression, list(player_id_map.keys()), gamelogs, player_perspective, card_names_map)
        
        # Add comprehensive resource/production/tag tracking if gamelogs available
        tracking_progression = []
        if gamelogs and player_id_map:
            logger.info("Adding comprehensive tracking data to game states")

            # Get player IDs for tracking
            player_ids = list(player_id_map.keys())

            # Track resources and production through all moves
            tracking_progression = self._track_resources_and_production(gamelogs, player_ids, tracker_dict, card_names_map, color_to_player_id, token_types)
            
            # Update game states with tracking data
            self._update_game_states_with_tracking(moves_with_states, tracking_progression)

        # Extract starting hands - prefer gamelogs, fallback to HTML
        starting_hands = self._extract_starting_hands_from_gamelogs(gamelogs, token_types)
        if not starting_hands:
            starting_hands = self._extract_starting_hands(soup, player_perspective)

        # Build final player objects from collected data
        players_info = self._build_final_players(player_id_map, corporations, moves_with_states, game_metadata, starting_hands, player_id_to_color)
        
        # Determine winner and whether the game was conceded from the final moves' descriptions
        winner, conceded = self._determine_winner_and_concession(moves_with_states)
        
        # Extract game metadata
        metadata = self._extract_metadata(soup, replay_html, moves_with_states)
        
        # Calculate max generation from vp_progression or moves
        max_generation = self._calculate_max_generation(vp_progression, moves_with_states)            

        # Collect draft directions per generation and strip from individual moves
        draft_directions: Dict[int, Dict[str, str]] = {}
        for m in moves_with_states:
            if m.draft_passed_to and m.game_state:
                gen = m.game_state.generation
                if gen not in draft_directions:
                    draft_directions[gen] = dict(m.draft_passed_to)
                m.draft_passed_to = None

        # Create game data with game metadata fields
        game_data = GameData(
            replay_id=table_id,
            player_perspective=player_perspective,
            game_date=self._extract_game_date(soup, game_metadata),
            game_duration=self._calculate_game_duration(moves_with_states),
            winner=winner,
            generations=max_generation,
            conceded=conceded,
            map=game_metadata.map,
            prelude_on=game_metadata.prelude_on,
            colonies_on=game_metadata.colonies_on,
            corporate_era_on=game_metadata.corporate_era_on,
            draft_on=game_metadata.draft_on,
            beginners_corporations_on=game_metadata.beginners_corporations_on,
            game_speed=game_metadata.game_speed,
            draft_directions=draft_directions or None,
            players=players_info,
            moves=moves_with_states,
            metadata=metadata
        )
        
        logger.info(f"Unified parsing complete for game {table_id}: {len(moves_with_states)} moves, {len(players_info)} players")
        return game_data
    
    def _get_player_id_map(self, game_metadata: GameMetadata) -> Dict[str, str]:
        """Extract player ID to name mapping from GameMetadata"""
        player_id_map = {}  # player_id -> player_name
        
        if game_metadata and game_metadata.players:
            logger.info("Extracting player IDs from GameMetadata")
            for player_id, elo_data in game_metadata.players.items():
                if elo_data.player_name:
                    player_id_map[player_id] = elo_data.player_name
                    logger.debug(f"GameMetadata: {player_id} -> {elo_data.player_name}")
            
            if player_id_map:
                logger.info(f"Successfully extracted {len(player_id_map)} players from GameMetadata")
                return player_id_map
        
        # If no player data available, raise an error
        logger.error("No player data available in GameMetadata")
        raise ValueError("Parser requires GameMetadata with player information")
    
    def _build_final_players(self, player_id_map: Dict[str, str], corporations: Dict[str, str],
                                               moves_with_states: List[Move], game_metadata: GameMetadata,
                                               starting_hands: Optional[Dict[str, StartingHand]],
                                               player_id_to_color: Dict[str, str] = None) -> Dict[str, Player]:
        """Build final player objects from collected data using GameMetadata"""
        players = {}
        
        # Get final VP data from the last move with game state
        final_vp_data = {}
        if moves_with_states:
            for move in reversed(moves_with_states):
                if move.game_state and move.game_state.player_vp:
                    final_vp_data = move.game_state.player_vp
                    break
        
        # Build player objects
        for player_id, player_name in player_id_map.items():
            # Get final VP and breakdown
            final_vp = 0
            vp_breakdown = {}
            if player_id in final_vp_data:
                final_vp = final_vp_data[player_id].get('total', 0)
                vp_breakdown = final_vp_data[player_id].get('total_details', {})
            
            # Collect cards played, milestones, awards from moves
            cards_played = []
            milestones_claimed = []
            awards_funded = []
            
            for move in moves_with_states:
                if move.player_id == player_id:
                    if move.card_played:
                        cards_played.append(move.card_played)
                    if move.action_type == 'claim_milestone':
                        milestone_match = re.search(r'claims milestone (.+?)(?:\s*\||$)', move.description)
                        if milestone_match:
                            milestones_claimed.append(milestone_match.group(1).strip())
                    if move.action_type == 'fund_award':
                        award_match = re.search(r'funds (.+?) award', move.description)
                        if award_match:
                            awards_funded.append(award_match.group(1).strip())
            
            # Get ELO data from GameMetadata
            elo_data = None
            if game_metadata and game_metadata.players and player_id in game_metadata.players:
                elo_data = game_metadata.players[player_id]

            # Get starting hand for this player
            starting_hand = starting_hands.get(player_id) if starting_hands else None
            
            players[player_id] = Player(
                player_id=player_id,
                player_name=player_name,
                corporation=corporations.get(player_name, 'Unknown'),
                final_vp=final_vp,
                final_tr=vp_breakdown.get('tr', 20),
                vp_breakdown=vp_breakdown,
                color=player_id_to_color.get(player_id) if player_id_to_color else None,
                starting_hand=starting_hand,
                cards_played=cards_played,
                milestones_claimed=milestones_claimed,
                awards_funded=awards_funded,
                elo_data=elo_data
            )
        
        logger.info(f"Built {len(players)} final player objects from GameMetadata")
        return players
    
    def _extract_game_date(self, soup: BeautifulSoup, game_metadata: GameMetadata) -> str:
        """Extract game date from GameMetadata or HTML"""
        # If GameMetadata has played_at timestamp, use it
        if game_metadata and game_metadata.played_at and game_metadata.played_at != "0001-01-01T00:00:00":
            try:
                # Parse the ISO timestamp and convert to date
                played_at_dt = datetime.fromisoformat(game_metadata.played_at.replace('Z', '+00:00'))
                return played_at_dt.strftime("%Y-%m-%d")
            except (ValueError, AttributeError) as e:
                logger.warning(f"Failed to parse played_at timestamp '{game_metadata.played_at}': {e}")
        
        # Fallback: Extract date from replay HTML
        try:
            # Look for date information in the replay HTML content
            html_content = str(soup)
            
            # Look for the specific replay HTML pattern: Move 1 :<span style="float: right">6/19/2025 6:03:06 PM</span>
            replay_date_pattern = r'<span[^>]*style="float:\s*right"[^>]*>(\d{1,2}/\d{1,2}/\d{4})\s+\d{1,2}:\d{2}:\d{2}\s+[AP]M</span>'
            replay_match = re.search(replay_date_pattern, html_content)
            
            if replay_match:
                date_str = replay_match.group(1)  # e.g., "6/19/2025"
                try:
                    # Parse as MM/DD/YYYY format (US format commonly used in BGA)
                    parsed_date = datetime.strptime(date_str, "%m/%d/%Y")
                    extracted_date = parsed_date.strftime("%Y-%m-%d")
                    logger.info(f"Extracted game date from replay HTML: {extracted_date} (from: {date_str})")
                    return extracted_date
                except ValueError:
                    # Try DD/MM/YYYY format as fallback
                    try:
                        parsed_date = datetime.strptime(date_str, "%d/%m/%Y")
                        extracted_date = parsed_date.strftime("%Y-%m-%d")
                        logger.info(f"Extracted game date from replay HTML: {extracted_date} (from: {date_str})")
                        return extracted_date
                    except ValueError:
                        logger.warning(f"Could not parse date from replay HTML: {date_str}")
            
            # Additional fallback: Look for other date patterns in HTML text
            date_patterns = [
                r'\b(\d{4}-\d{2}-\d{2})\b',  # YYYY-MM-DD
                r'\b(\d{1,2}/\d{1,2}/\d{4})\b',  # MM/DD/YYYY or DD/MM/YYYY
                r'\b(\d{1,2}-\d{1,2}-\d{4})\b',  # MM-DD-YYYY or DD-MM-YYYY
            ]
            
            for pattern in date_patterns:
                matches = re.findall(pattern, html_content)
                for match in matches:
                    try:
                        # Try to parse the date
                        if '-' in match and len(match.split('-')[0]) == 4:
                            # YYYY-MM-DD format
                            parsed_date = datetime.strptime(match, "%Y-%m-%d")
                        elif '/' in match:
                            # Try MM/DD/YYYY format first (US format)
                            try:
                                parsed_date = datetime.strptime(match, "%m/%d/%Y")
                            except ValueError:
                                # Try DD/MM/YYYY format
                                parsed_date = datetime.strptime(match, "%d/%m/%Y")
                        elif '-' in match:
                            # Try MM-DD-YYYY format first
                            try:
                                parsed_date = datetime.strptime(match, "%m-%d-%Y")
                            except ValueError:
                                # Try DD-MM-YYYY format
                                parsed_date = datetime.strptime(match, "%d-%m-%Y")
                        else:
                            continue
                        
                        # Validate that the date is reasonable (not too far in the future or past)
                        current_date = datetime.now()
                        if (current_date - timedelta(days=365*5)) <= parsed_date <= (current_date + timedelta(days=30)):
                            extracted_date = parsed_date.strftime("%Y-%m-%d")
                            logger.info(f"Extracted game date from HTML pattern: {extracted_date}")
                            return extracted_date
                            
                    except ValueError:
                        continue
            
            logger.warning("Could not extract game date from replay HTML, using current date as fallback")
            
        except Exception as e:
            logger.error(f"Error extracting game date from HTML: {e}")
        
        # Final fallback: use current date
        return datetime.now().strftime("%Y-%m-%d")
    
    def _extract_all_moves(self, soup: BeautifulSoup, players_info: Dict[str, Player], gamelogs: Dict[str, Any] = None) -> List[Move]:
        """Extract all moves with detailed information"""
        moves = []
        move_divs = soup.find_all('div', class_='replaylogs_move')
        
        # Create reverse lookup for player names to IDs
        name_to_id = {player.player_name: player_id for player_id, player in players_info.items()}
        
        for move_div in move_divs:
            move = self._parse_single_move_detailed(move_div, name_to_id, gamelogs)
            if move:
                moves.append(move)
                
                # Update player data based on move
                self._update_player_data_from_move(move, players_info)
        
        return moves
    
    def _parse_single_move_detailed(self, move_div: Tag, name_to_id: Dict[str, str], gamelogs: Dict[str, Any] = None, card_names_map: Dict[str, str] = None, tracker_dict: Dict[str, str] = None) -> Optional[Move]:
        """Parse a single move with comprehensive detail extraction"""
        try:
            # Extract move number and timestamp
            move_info = move_div.find('div', class_='smalltext')
            if not move_info:
                return None
            
            move_text = move_info.get_text()
            move_match = re.search(r'Move (\d+)', move_text)
            if not move_match:
                return None
            
            move_number = int(move_match.group(1))
            
            # Extract timestamp
            timestamp_match = re.search(r'(\d{1,2}:\d{2}:\d{2})', move_text)
            timestamp = timestamp_match.group(1) if timestamp_match else ""
            
            # Extract all log entries
            log_entries = move_div.find_all('div', class_='gamelogreview')
            if not log_entries:
                return None
            
            # Combine descriptions
            descriptions = [entry.get_text().strip() for entry in log_entries]
            full_description = ' | '.join(descriptions)
            
            # Determine player - use gamelogs first, then fallback to HTML parsing
            player_name, player_id = self._determine_player_from_gamelogs(move_number, gamelogs, name_to_id)
            if player_id == "unknown":
                # Fallback to HTML-based player determination
                player_name, player_id = self._determine_move_player(log_entries, full_description, name_to_id)
            
            # Detect takebacks before doing any draft/play processing
            if gamelogs and self._is_takeback_move(move_number, gamelogs):
                return Move(
                    move_number=move_number,
                    timestamp=timestamp,
                    player_id=player_id,
                    player_name=player_name,
                    action_type='takeback',
                    description=f"{player_name} takes back their move",
                    reason='takeback',
                )

            # Extract enhanced action details from gamelogs if available
            action_type, card_played, tile_placed, tile_location, reason = self._extract_enhanced_action_details(
                move_number, gamelogs, log_entries, full_description
            )

            # Map card_played, tile_placed, and tile_location IDs to names
            if card_played and card_names_map and card_played in card_names_map:
                card_played = card_names_map[card_played]
            if tile_placed and card_names_map and tile_placed in card_names_map:
                tile_placed = card_names_map[tile_placed]
            if tile_location:
                hex_name = card_names_map.get(tile_location) if card_names_map else None
                coords_match = re.match(r'hex_(\d+)_(\d+)', tile_location)
                if hex_name and coords_match:
                    tile_location = f"{hex_name} ({coords_match.group(1)},{coords_match.group(2)})"
                elif hex_name:
                    tile_location = hex_name
                elif coords_match:
                    tile_location = f"Hex {coords_match.group(1)},{coords_match.group(2)}"

            # Map IDs to names and compute per-player card options (draws and drafts)
            card_options_map: Optional[Dict[str, List[str]]] = None
            card_drafted_name: Optional[str] = None
            draft_desc_text: Optional[str] = None
            cards_kept_map: Optional[Dict[str, List[str]]] = None
            try:
                # Collect per-player draft draws and normal draws separately
                per_player_draft_ids: Dict[str, List[str]] = {}
                per_player_draw_ids: Dict[str, List[str]] = {}
                per_player_setup_ids: Dict[str, List[str]] = {}
                per_player_kept_ids: Dict[str, List[str]] = {}
                per_player_names: Dict[str, str] = {}
                color_to_pid: Dict[str, str] = {}  # hex color -> player_id (from draft_ place_ids)
                if gamelogs:
                    data_entries = gamelogs.get('data', {}).get('data', [])
                    for entry in data_entries:
                        if entry.get('move_id') == str(move_number):
                            entry_data = entry.get('data', [])
                            if isinstance(entry_data, list):
                                for data_item in entry_data:
                                    if isinstance(data_item, dict) and data_item.get('type') == 'tokenMoved':
                                        args = data_item.get('args', {})
                                        if not isinstance(args, dict):
                                            continue
                                        # Infer draft via place_id/place_name prefix; do not require place_from
                                        place_tag = args.get('place_id', '') or args.get('place_name', '')
                                        id_list = args.get('list', [])
                                        pid = str(args.get('player_id')) if args.get('player_id') is not None else "unknown"
                                        if isinstance(id_list, list):
                                            ids = [tid for tid in id_list if isinstance(tid, str)]
                                        else:
                                            ids = []
                                        if isinstance(place_tag, str) and str(place_tag).lower().startswith('draft_'):
                                            if ids:
                                                per_player_draft_ids.setdefault(pid, []).extend(ids)
                                            if isinstance(args.get('player_name'), str) and pid != "unknown":
                                                per_player_names[pid] = args.get('player_name')
                                            # Map draft color to player_id (e.g. draft_008000 -> pid)
                                            color = place_tag[6:]  # strip 'draft_'
                                            if color and pid != "unknown":
                                                color_to_pid[color.lower()] = pid
                                        elif isinstance(place_tag, str) and str(place_tag).lower().startswith('hand_'):
                                            if ids:
                                                per_player_kept_ids.setdefault(pid, []).extend(ids)
                                            if isinstance(args.get('player_name'), str) and pid != "unknown":
                                                per_player_names[pid] = args.get('player_name')
                                        else:
                                            if ids:
                                                per_player_draw_ids.setdefault(pid, []).extend(ids)
                                            if isinstance(args.get('player_name'), str) and pid != "unknown":
                                                per_player_names[pid] = args.get('player_name')
                                        # Also capture individual token arrivals to a draft or hand area as options/kept (no list provided)
                                        tok_id = args.get('token_id')
                                        if isinstance(place_tag, str) and str(place_tag).lower().startswith('draft_') and isinstance(tok_id, str):
                                            per_player_draft_ids.setdefault(pid, []).append(tok_id)
                                            if isinstance(args.get('player_name'), str) and pid != "unknown":
                                                per_player_names[pid] = args.get('player_name')
                                        if isinstance(place_tag, str) and str(place_tag).lower().startswith('hand_') and isinstance(tok_id, str):
                                            per_player_kept_ids.setdefault(pid, []).append(tok_id)
                                            if isinstance(args.get('player_name'), str) and pid != "unknown":
                                                per_player_names[pid] = args.get('player_name')
                # Merge newPrivateState draft targets into per_player_draft_ids for this move
                # and extract draft pass direction from owner/next_color fields
                draft_passed_to_map: Optional[Dict[str, str]] = None
                try:
                    if gamelogs:
                        data_entries = gamelogs.get('data', {}).get('data', [])
                        for entry in data_entries:
                            if entry.get('move_id') == str(move_number):
                                entry_data = entry.get('data', [])
                                if isinstance(entry_data, list):
                                    for data_item in entry_data:
                                        if isinstance(data_item, dict) and data_item.get('type') == 'newPrivateState':
                                            nps_args = data_item.get('args', {}) or {}
                                            inner = nps_args.get('args', {}) if isinstance(nps_args.get('args', {}), dict) else {}
                                            player_operations = inner.get('player_operations', {})
                                            if isinstance(player_operations, dict):
                                                for pid_key, pop in player_operations.items():
                                                    if not isinstance(pop, dict):
                                                        continue
                                                    operations = pop.get('operations', {})
                                                    if isinstance(operations, dict):
                                                        for op in operations.values():
                                                            if not isinstance(op, dict):
                                                                continue
                                                            otype = op.get('type') or op.get('typeexpr')
                                                            if otype == 'draft':
                                                                targ = op.get('args', {}).get('target', [])
                                                                if isinstance(targ, list):
                                                                    ids = [tid for tid in targ if isinstance(tid, str)]
                                                                    if ids:
                                                                        per_player_draft_ids.setdefault(str(pid_key), []).extend(ids)
                                                                # Extract draft pass direction
                                                                # next_color is nested at op.args.args.next_color
                                                                op_outer_args = op.get('args', {})
                                                                if not isinstance(op_outer_args, dict):
                                                                    op_outer_args = {}
                                                                op_inner_args = op_outer_args.get('args', {})
                                                                if not isinstance(op_inner_args, dict):
                                                                    op_inner_args = {}
                                                                next_color = op_inner_args.get('next_color', '')
                                                                owner_color = op.get('owner', '')
                                                                if next_color and owner_color:
                                                                    from_pid = color_to_pid.get(owner_color.lower())
                                                                    to_pid = color_to_pid.get(next_color.lower())
                                                                    if from_pid and to_pid:
                                                                        if draft_passed_to_map is None:
                                                                            draft_passed_to_map = {}
                                                                        draft_passed_to_map[from_pid] = to_pid
                                                            elif otype == 'setuppick':
                                                                # Starting hand options (corporation, preludes, projects). We only want project cards.
                                                                targ = op.get('args', {}).get('target', [])
                                                                if isinstance(targ, list):
                                                                    ids = [tid for tid in targ if isinstance(tid, str) and tid.startswith('card_main_')]
                                                                    if ids:
                                                                        per_player_setup_ids.setdefault(str(pid_key), []).extend(ids)
                except Exception:
                    pass

                # Build unified card_options map (player_id -> list of names) from both sources
                if card_names_map and (per_player_draft_ids or per_player_draw_ids or per_player_setup_ids):
                    card_options: Dict[str, List[str]] = {}
                    combined: Dict[str, List[str]] = {}
                    # Merge keys; ensure copies
                    for pid, ids in per_player_draw_ids.items():
                        combined.setdefault(pid, []).extend(list(ids))
                    for pid, ids in per_player_draft_ids.items():
                        combined.setdefault(pid, []).extend(list(ids))
                    for pid, ids in per_player_setup_ids.items():
                        combined.setdefault(pid, []).extend(list(ids))
                    # Map to names and dedupe while preserving order
                    for pid, ids in combined.items():
                        names = [card_names_map.get(tid) for tid in ids]
                        names = [n for n in names if isinstance(n, str) and n.strip()]
                        if names:
                            # dedupe preserving order
                            deduped = list(dict.fromkeys(names))
                            card_options.setdefault(pid, []).extend(deduped)
                    if card_options:
                        card_options_map = card_options
                        # Override description to map per-player actions clearly
                        try:
                            id_to_name = {mapped_id: pname for pname, mapped_id in name_to_id.items()}
                            parts: List[str] = []
                            # Prefer showing draft per-player if exists; else show draws
                            source = per_player_draft_ids if per_player_draft_ids else per_player_draw_ids
                            for pid, ids in source.items():
                                names = [card_names_map.get(tid) for tid in ids]
                                names = [n for n in names if isinstance(n, str) and n.strip()]
                                # dedupe for description as well
                                names = list(dict.fromkeys(names))
                                pname = per_player_names.get(pid) or id_to_name.get(pid, f"Player_{pid}")
                                verb = "drafts" if source is per_player_draft_ids else "draws"
                                if len(names) == 1:
                                    parts.append(f"{pname} {verb} {names[0]}")
                                else:
                                    parts.append(f"{pname} {verb} {len(names)} cards: {', '.join(names)}")
                            if parts:
                                full_description = " | ".join(parts)
                                if source is per_player_draft_ids and action_type in ('other', 'draw', 'draft_card'):
                                    action_type = 'draft'
                                if source is per_player_draw_ids and action_type == 'other':
                                    action_type = 'draw'
                                card_played = None
                        except Exception:
                            pass
                # Map kept cards (to hand_*) to names per player
                if card_names_map and per_player_kept_ids:
                    cards_kept = {}
                    for pid, ids in per_player_kept_ids.items():
                        names = [card_names_map.get(tid) for tid in ids]
                        names = [n for n in names if isinstance(n, str) and n.strip()]
                        if names:
                            deduped = list(dict.fromkeys(names))
                            cards_kept[pid] = deduped
                    if cards_kept:
                        cards_kept_map = cards_kept
                        # If we have explicit kept cards this move, build a concise per-player description
                        # Use "draws" for action_type=draw, otherwise use "keeps"
                        try:
                            id_to_name = {mapped_id: pname for pname, mapped_id in name_to_id.items()}
                            parts: List[str] = []
                            for pid, names in cards_kept_map.items():
                                pname = per_player_names.get(pid) or id_to_name.get(pid, f"Player_{pid}")
                                # Choose verb based on action_type
                                verb = "draws" if action_type == "draw" else "keeps"
                                if len(names) == 1:
                                    parts.append(f"{pname} {verb} {names[0]}")
                                else:
                                    parts.append(f"{pname} {verb} {len(names)} cards: {', '.join(names)}")
                            if parts:
                                full_description = " | ".join(parts)
                        except Exception:
                            pass
                # Detect a concrete drafted selection (tokenMoved with 'draft' context)
                if gamelogs and card_names_map and card_drafted_name is None:
                    data_entries = gamelogs.get('data', {}).get('data', [])
                    for entry in data_entries:
                        if entry.get('move_id') == str(move_number):
                            entry_data = entry.get('data', [])
                            if isinstance(entry_data, list):
                                for data_item in entry_data:
                                    if isinstance(data_item, dict) and data_item.get('type') == 'tokenMoved':
                                        log_txt = (data_item.get('log') or '').lower()
                                        args = data_item.get('args', {}) or {}
                                        place_tag = str(args.get('place_id', '') or args.get('place_name', '')).lower()
                                        token_id = args.get('token_id')
                                        # Detect a concrete selection (draft/keep) for this move's player:
                                        # - Only set action_type to 'draft' if log contains 'draft' OR destination looks like draw_*
                                        # - For keep/hand_ selections without 'draft' markers, do NOT force 'draft'
                                        # - args.player_id matches the resolved player_id for this move
                                        sel_pid = str(args.get('player_id')) if args.get('player_id') is not None else "unknown"
                                        is_draft_selection = (
                                            ('draft' in log_txt) or
                                            place_tag.startswith('draw_')
                                        )
                                        is_keep_selection = (
                                            ('keep' in log_txt) or
                                            ('keeps' in log_txt) or
                                            place_tag.startswith('hand_')
                                        )
                                        is_selection = is_draft_selection or is_keep_selection
                                        if token_id and is_selection and sel_pid == str(player_id):
                                            if token_id in card_names_map:
                                                card_drafted_name = card_names_map[token_id]
                                            else:
                                                card_drafted_name = token_id
                                            # Prepare precise description using original template text
                                            try:
                                                log_template = data_item.get('log') or ''
                                                if isinstance(log_template, str) and card_drafted_name:
                                                    draft_desc_text = re.sub(r'\$\{token_name\}', card_drafted_name, log_template)
                                            except Exception:
                                                pass
                                            # Only set action_type to 'draft' for actual draft selections
                                            if is_draft_selection and action_type in ('other', 'draw', 'draft_card'):
                                                action_type = 'draft'
                                                if not reason:
                                                    reason = 'draft'
                                            # For keep selections, don't force action_type change
                                            break
                                if card_drafted_name:
                                    break
                        if card_drafted_name:
                            break
            except Exception as map_err:
                logger.debug(f"Move {move_number}: mapping card IDs to names failed: {map_err}")
            
            # Prefer specific draft selection description when available
            try:
                # Do not override a multi-buy summary when cards_kept_map exists
                if card_drafted_name and not cards_kept_map:
                    if isinstance(draft_desc_text, str) and draft_desc_text.strip():
                        full_description = draft_desc_text.strip()
                    else:
                        full_description = f"{player_name} drafts {card_drafted_name}"
            except Exception:
                pass

            # Enrich counter descriptions from gamelogs (simple rendering):
            # For each 'counter' item with a non-empty log, render the template by substituting args
            # (mapping ${token_name} to human-readable via _infer_from_tracker_id) and append reason_tr if present.
            # Then replace any matching 'player <verb> by N' segment in the current description with this rendered text.
            try:
                if gamelogs:
                    data_entries = gamelogs.get('data', {}).get('data', [])
                    parts = [p.strip() for p in full_description.split(' | ')] if isinstance(full_description, str) else []
                    changed = False
                    for entry in data_entries:
                        if entry.get('move_id') != str(move_number):
                            continue
                        entry_data = entry.get('data', [])
                        if not isinstance(entry_data, list):
                            continue
                        for data_item in entry_data:
                            if not isinstance(data_item, dict) or data_item.get('type') != 'counter':
                                continue
                            log_t = data_item.get('log') or ''
                            if not isinstance(log_t, str) or not log_t.strip():
                                continue  # skip counters without log text (e.g., counterAsync-like)
                            args = data_item.get('args', {}) or {}
                            # Filter to this move's player when possible
                            pid = str(args.get('player_id')) if args.get('player_id') is not None else None
                            if pid and player_id != "unknown" and pid != str(player_id):
                                continue
                            # Consider all counter logs with text (including 'pays', 'gains', etc.)
                            lower_tpl = log_t.lower()
                            # Render the main log template
                            rendered = self._render_bga_log_template(log_t, args, tracker_dict)
                            # Render and append reason if available
                            rtr = args.get('reason_tr')
                            if isinstance(rtr, dict):
                                reason_rendered = self._render_bga_log_template(rtr.get('log', ''), rtr.get('args', {}), tracker_dict)
                                if isinstance(reason_rendered, str) and reason_rendered.strip():
                                    rendered = f"{rendered} ({reason_rendered.strip()})"
                            # Rendered replacement: replace the matching part for this counter line based on verb and amount
                            # Determine mod and verb generically from template (no special-casing)
                            try:
                                mod_val = args.get('mod')
                                mod_int = abs(int(mod_val)) if isinstance(mod_val, (int, str)) and re.fullmatch(r'-?\d+', str(mod_val)) else None
                            except Exception:
                                mod_int = None
                            # Try to extract verb from template after ${player_name}
                            verb_match = re.match(r'\s*\$\{player_name\}\s+([A-Za-z]+)', log_t)
                            if verb_match:
                                verb = verb_match.group(1)
                            else:
                                # Fallback: extract from rendered text after actual player_name
                                verb_fallback = re.match(rf'\s*{re.escape(player_name)}\s+([A-Za-z]+)', rendered)
                                verb = verb_fallback.group(1) if verb_fallback else None

                            if parts and verb:
                                if mod_int is not None:
                                    # Match the existing part by same player, same verb, and same numeric amount
                                    patt = re.compile(rf'(?i)^{re.escape(player_name)}\s+{verb}\b.*?\b{mod_int}\b(?:\s*\((?:[^)]*)\))?$', re.IGNORECASE)
                                else:
                                    # If no numeric amount, match just player + verb line
                                    patt = re.compile(rf'(?i)^{re.escape(player_name)}\s+{verb}\b.*$', re.IGNORECASE)
                                replaced = False
                                for i, part in enumerate(parts):
                                    if patt.match(part):
                                        parts[i] = rendered
                                        changed = True
                                        replaced = True
                                        break
                                # Fallback: sometimes HTML omits the player name in that part (e.g., "increases by 1")
                                # Try matching by verb and amount only, and only replace if the token segment is empty.
                                if not replaced and (mod_int is not None):
                                    patt2 = re.compile(
                                        rf'(?i)^\s*{verb}\s+(.*?)\s+by\s+{mod_int}(\s*\((?:[^)]*)\))?$',
                                        re.IGNORECASE
                                    )
                                    for i, part in enumerate(parts):                                   
                                        m2 = patt2.match(part)
                                        if not m2:
                                            continue
                                        token_seg = (m2.group(1) or "").strip()
                                        if token_seg:
                                            continue  # keep lines that already have a token name                                   
                                        parts[i] = rendered
                                        changed = True
                                        replaced = True
                                        break
                                if not replaced:
                                    if isinstance(rendered, str) and rendered.strip() and rendered not in parts:
                                        parts.append(rendered)
                                        changed = True
                    if changed:
                        full_description = " | ".join(parts)
            except Exception:
                pass

            # Detect discarded cards (sell patents, card effects like Mars University, etc.)
            # Skip draft/draw moves where "discards" are just cards passed to other players
            cards_discarded_list: Optional[List[str]] = None
            try:
                if gamelogs:
                    data_entries_sell = gamelogs.get('data', {}).get('data', [])
                    discarded_card_ids: List[str] = []
                    has_draft_pass = False
                    revealed_card_ids: set = set()
                    for entry in data_entries_sell:
                        if entry.get('move_id') != str(move_number):
                            continue
                        entry_data = entry.get('data', [])
                        if not isinstance(entry_data, list):
                            continue
                        for data_item in entry_data:
                            if not isinstance(data_item, dict):
                                continue
                            if data_item.get('type') == 'tokenMoved':
                                tm_args = data_item.get('args') or {}
                                place_id = str(tm_args.get('place_id', '') or tm_args.get('place_name', ''))
                                token_id = tm_args.get('token_id', '')
                                if place_id.startswith('draft_'):
                                    has_draft_pass = True
                                if place_id == 'reveal' and isinstance(token_id, str) and token_id.startswith('card_main_'):
                                    revealed_card_ids.add(token_id)
                                if place_id == 'discard_main' and isinstance(token_id, str) and token_id.startswith('card_main_'):
                                    # Only count as discard if not a revealed deck card
                                    if token_id not in revealed_card_ids:
                                        discarded_card_ids.append(token_id)
                    if discarded_card_ids and not has_draft_pass:
                        cards_discarded_list = []
                        for cid in discarded_card_ids:
                            if card_names_map and cid in card_names_map:
                                cards_discarded_list.append(card_names_map[cid])
                            else:
                                cards_discarded_list.append(cid)
            except Exception:
                pass

            move = Move(
                move_number=move_number,
                timestamp=timestamp,
                player_id=player_id,
                player_name=player_name,
                action_type=action_type,
                description=full_description,
                card_played=card_played,
                card_drafted=card_drafted_name,
                tile_placed=tile_placed,
                tile_location=tile_location,
                card_options=card_options_map,
                cards_kept=cards_kept_map,
                cards_discarded=cards_discarded_list,
                draft_passed_to=draft_passed_to_map,
                reason=reason
            )

            return move
            
        except Exception as e:
            logger.error(f"Error parsing move: {e}")
            return None
    
    def _determine_player_from_gamelogs(self, move_number: int, gamelogs: Dict[str, Any], name_to_id: Dict[str, str]) -> Tuple[str, str]:
        """Determine which player made this move using gamelogs data (preferred method)"""
        if not gamelogs:
            return "Unknown", "unknown"
        
        try:
            # Find all entries for this move in gamelogs (across all channels)
            data_entries = gamelogs.get('data', {}).get('data', [])
            move_entries = [entry for entry in data_entries if entry.get('move_id') == str(move_number)]

            if not move_entries:
                logger.debug(f"No gamelogs entry found for move {move_number}")
                return "Unknown", "unknown"

            # Search through all data items to find a player_id/active_player
            found_player_id: Optional[str] = None
            for entry in move_entries:
                move_data = entry.get('data', [])
                if not isinstance(move_data, list):
                    continue
                for data_item in move_data:
                    if not isinstance(data_item, dict):
                        continue
                    args = data_item.get('args', {}) or {}
                    if 'active_player' in args:
                        found_player_id = str(args['active_player'])
                        logger.debug(f"Move {move_number}: Found active_player = {found_player_id}")
                        break
                    if 'player_id' in args:
                        found_player_id = str(args['player_id'])
                        logger.debug(f"Move {move_number}: Found player_id = {found_player_id}")
                        break
                if found_player_id:
                    break

            if not found_player_id:
                # Fallback: look for player_name and reverse-map to ID
                for entry in move_entries:
                    move_data = entry.get('data', [])
                    if not isinstance(move_data, list):
                        continue
                    for data_item in move_data:
                        if not isinstance(data_item, dict):
                            continue
                        args = data_item.get('args', {}) or {}
                        pname = args.get('player_name')
                        if isinstance(pname, str) and pname in name_to_id:
                            found_player_id = name_to_id[pname]
                            logger.debug(f"Move {move_number}: Found player via player_name '{pname}' -> {found_player_id}")
                            break
                    if found_player_id:
                        break

            if not found_player_id:
                logger.debug(f"Move {move_number}: No player ID found in gamelogs args across entries")
                return "Unknown", "unknown"

            # Map to name using provided mapping
            for player_name, mapped_id in name_to_id.items():
                if mapped_id == found_player_id:
                    logger.debug(f"Move {move_number}: Mapped player_id {found_player_id} to {player_name}")
                    return player_name, found_player_id

            # If no mapping found, return the player_id as both name and id
            logger.debug(f"Move {move_number}: No name mapping found for player_id {found_player_id}, using ID as name")
            return f"Player_{found_player_id}", found_player_id
            
        except Exception as e:
            logger.error(f"Error determining player from gamelogs for move {move_number}: {e}")
            return "Unknown", "unknown"
    
    def _determine_move_player(self, log_entries: List[Tag], description: str, name_to_id: Dict[str, str]) -> Tuple[str, str]:
        """Determine which player made this move (fallback method using HTML parsing)"""
        # Look for explicit player mentions
        for entry in log_entries:
            text = entry.get_text()
            
            # Check for player names in the text
            for player_name in name_to_id.keys():
                if player_name in text and any(verb in text for verb in ['plays', 'pays', 'gains', 'increases', 'reduces', 'places', 'chooses']):
                    return player_name, name_to_id[player_name]
            
            # Handle "You" references - would need context to resolve properly
            if text.startswith('You '):
                # For now, return as "You" - could be improved with more context
                return "You", "you"
        
        return "Unknown", "unknown"
    
    def _extract_enhanced_action_details(self, move_number: int, gamelogs: Dict[str, Any], 
                                        log_entries: List[Tag], description: str) -> Tuple[str, Optional[str], Optional[str], Optional[str], Optional[str]]:
        """
        Extract enhanced action details from gamelogs data with fallback to HTML parsing.
        
        Returns:
            Tuple of (action_type, card_played, tile_placed, tile_location, reason)
        """
        reason_from_gamelogs = None

        # First try to extract from gamelogs
        if gamelogs:
            action_type, card_played, tile_placed, tile_location, reason = self._extract_action_details_from_gamelogs(
                move_number, gamelogs
            )
            reason_from_gamelogs = reason
            
            # If we got meaningful data from gamelogs, return it
            # Only short-circuit when we truly identified a specific action or the played card.
            # Do NOT short-circuit on plain 'draw' with a reason, since HTML may contain "plays card ..."
            if (card_played is not None) or (action_type not in ('other', 'draw')) or (tile_location is not None):
                return action_type, card_played, tile_placed, tile_location, reason
        
        # Fallback to HTML-based extraction
        action_type = self._classify_action_type(log_entries, description)
        card_played = self._extract_card_played(log_entries)
        tile_placed, tile_location = self._extract_tile_placement(log_entries)
        
        return action_type, card_played, tile_placed, tile_location, reason_from_gamelogs
    
    def _extract_action_details_from_gamelogs(self, move_number: int, gamelogs: Dict[str, Any]) -> Tuple[str, Optional[str], Optional[str], Optional[str], Optional[str]]:
        """Extract detailed action information from gamelogs data"""
        try:
            # Find all entries for this move
            data_entries = gamelogs.get('data', {}).get('data', [])
            move_entries = [entry for entry in data_entries if entry.get('move_id') == str(move_number)]
            
            if not move_entries:
                return 'other', None, None, None, None
            
            # Analyze all data items across all entries for this move
            action_type = 'other'
            card_played = None
            tile_placed = None
            tile_location = None
            reason = None
            has_discard_hidden = False
            has_m_gain_action = False

            for entry in move_entries:
                entry_data = entry.get('data', [])
                if not isinstance(entry_data, list):
                    continue
                
                for data_item in entry_data:
                    if not isinstance(data_item, dict):
                        continue
                    
                    item_type = data_item.get('type', '')
                    args = data_item.get('args', {})
                    
                    # Analyze different types of actions
                    if item_type == 'tokenMoved':
                        # Card play/draw/draft classification
                        place_from = (args.get('place_from') or '').lower()
                        place_to = str(args.get('place_id', '') or args.get('place_name', '')).lower()

                        # 1) Prefer play detection: moving a card from hand implies 'play_card'
                        if 'list' in args and ('hand' in place_from):
                            action_type = 'play_card'
                            card_list = args.get('list', [])
                            if isinstance(card_list, list) and len(card_list) > 0:
                                card_played = card_list[0]
                                logger.debug(f"Move {move_number}: Detected card play from hand - {card_played}")

                        # 2) Concrete token_id moves (no list)
                        elif 'token_id' in args:
                            log_txt = (data_item.get('log') or '').lower()
                            token_id_val = args.get('token_id', '')
                            # Tile placement: tile token placed on a hex
                            if isinstance(token_id_val, str) and token_id_val.startswith('tile_') and 'places' in log_txt:
                                action_type = 'place_tile'
                                # Derive tile type from token_id (strip instance suffix: tile_2_1 -> tile_2)
                                tile_base = re.sub(r'_\d+$', '', token_id_val)
                                tile_placed = tile_base
                                tile_location = args.get('place_id') or args.get('place_name') or ''
                                logger.debug(f"Move {move_number}: Detected tile placement {tile_base} on {tile_location}")
                            # Marker placement on hex (e.g. Land Claim player cube)
                            elif isinstance(token_id_val, str) and token_id_val.startswith('marker_') and isinstance(args.get('place_id', ''), str) and args.get('place_id', '').startswith('hex_'):
                                tile_location = args['place_id']
                                logger.debug(f"Move {move_number}: Detected marker placement on {tile_location}")
                            # Card play: "plays card" in log (not activations)
                            elif 'plays card' in log_txt:
                                action_type = 'play_card'
                                if isinstance(token_id_val, str) and token_id_val.startswith(('card_main_', 'card_prelude_', 'card_corp_')):
                                    card_played = token_id_val
                                logger.debug(f"Move {move_number}: Detected card play via token_id={token_id_val}")
                            # Card activation
                            elif 'activates' in log_txt:
                                action_type = 'activate_card'
                                logger.debug(f"Move {move_number}: Detected card activation via token_id={token_id_val}")
                            # Milestone claim
                            elif 'claims milestone' in log_txt:
                                action_type = 'claim_milestone'
                                logger.debug(f"Move {move_number}: Detected milestone claim")
                            # Award funding
                            elif 'funds' in log_txt and 'award' in log_txt:
                                action_type = 'fund_award'
                                logger.debug(f"Move {move_number}: Detected award funding")
                            # Draft selection
                            elif 'draft' in log_txt or place_to.startswith('draw_'):
                                if action_type == 'other':
                                    action_type = 'draft'
                                if reason is None:
                                    reason = 'draft'
                                logger.debug(f"Move {move_number}: Detected draft selection token_id={token_id_val}")

                        # 3) Draft options: arrivals to draft_* lists
                        elif 'list' in args and place_to.startswith('draft_'):
                            if action_type == 'other':
                                action_type = 'draft'
                            logger.debug(f"Move {move_number}: Detected draft options to {place_to}")

                        # 4) Draws: generic draws from deck (do not set card_played here)
                        elif 'list' in args:
                            if action_type == 'other':
                                action_type = 'draw'
                            logger.debug(f"Move {move_number}: Detected draw (list size {len(args.get('list', []))})")
                    
                    elif item_type == 'tokenMovedHidden':
                        # Detect sell patents (card discard for M€)
                        reason_tr = args.get('reason_tr')
                        if isinstance(reason_tr, str) and 'sell patents' in reason_tr.lower():
                            action_type = 'sell_cards'
                            reason = 'Sell patents'
                            logger.debug(f"Move {move_number}: Detected sell patents action")
                        # Track discards for fallback sell detection (older format)
                        elif 'discards' in (data_item.get('log') or '').lower():
                            has_discard_hidden = True

                    elif item_type == 'counter':
                        # Detect convert heat: pays Heat + increases Temperature
                        if action_type == 'other':
                            counter_name = str(args.get('counter_name', ''))
                            if re.match(r'^tracker_t$', counter_name):
                                log_txt = (data_item.get('log') or '').lower()
                                if 'increases' in log_txt:
                                    action_type = 'convert_heat'
                                    logger.debug(f"Move {move_number}: Detected convert heat action")
                        # Track M€ gains for fallback sell detection
                        counter_name = str(args.get('counter_name', ''))
                        if 'gains' in (data_item.get('log') or '') and re.match(r'tracker_m_[0-9a-fA-F]{6}$', counter_name):
                            has_m_gain_action = True

                    elif item_type == 'gameStateChange':
                        # Inspect nested operations for draw and reason
                        gs_args = data_item.get('args', {})
                        inner = gs_args.get('args', {})
                        ops = None
                        if isinstance(inner, dict):
                            ops = inner.get('operations')
                        if isinstance(ops, dict):
                            for op in ops.values():
                                if not isinstance(op, dict):
                                    continue
                                op_type = op.get('type') or op.get('typeexpr')
                                op_args = op.get('args', {})
                                # Extract reason if present
                                if isinstance(op_args, dict) and 'reason' in op_args and reason is None:
                                    r = op_args.get('reason')
                                    if isinstance(r, dict):
                                        try:
                                            tpl = r.get('log', '')
                                            amap = r.get('args', {}) if isinstance(r.get('args', {}), dict) else {}
                                            # Replace ${var} placeholders with values
                                            reason_str = re.sub(r'\$\{([^}]+)\}', lambda m: str(amap.get(m.group(1), m.group(0))), tpl)
                                            if isinstance(reason_str, str) and reason_str.strip():
                                                reason = reason_str.strip()
                                                logger.debug(f"Move {move_number}: Found reason '{reason}'")
                                        except Exception:
                                            pass
                                    elif isinstance(r, str):
                                        rs = r.strip()
                                        if rs:
                                            reason = rs
                                            logger.debug(f"Move {move_number}: Found reason '{reason}'")
                                # Resolve hex IDs in reason
                                if isinstance(reason, str):
                                    hex_match = re.match(r'^hex_(\d+)_(\d+)$', reason)
                                    if hex_match:
                                        reason = f"Hex {hex_match.group(1)},{hex_match.group(2)}"
                                # Classify action from reason text
                                if action_type == 'other' and isinstance(reason, str):
                                    if reason.startswith('immediate effect of '):
                                        action_type = 'immediate_effect'
                                        logger.debug(f"Move {move_number}: Detected immediate effect action")
                                    elif reason.startswith('activation effect of '):
                                        action_type = 'activation_effect'
                                        logger.debug(f"Move {move_number}: Detected activation effect action")
                                # If operation indicates a draw/draft, classify accordingly
                                if (op_type == 'draw' or op.get('typeexpr') == 'draw') and action_type == 'other':
                                    action_type = 'draw'
                                    logger.debug(f"Move {move_number}: Detected draw action from gameStateChange operations")
                                elif (op_type == 'draft' or op.get('typeexpr') == 'draft') and action_type == 'other':
                                    action_type = 'draft'
                                    logger.debug(f"Move {move_number}: Detected draft action from gameStateChange operations")
                    
                    elif item_type == 'message':
                        # Look for specific message patterns
                        log_msg = data_item.get('log', '')
                        if action_type == 'other' and 'draws' in log_msg and 'cards' in log_msg:
                            action_type = 'draw'
                            logger.debug(f"Move {move_number}: Detected draw action from message")
                        elif action_type == 'other' and 'plays card' in log_msg:
                            action_type = 'play_card'
                            logger.debug(f"Move {move_number}: Detected play card from message")
                        elif action_type == 'other' and 'standard project' in log_msg.lower():
                            action_type = 'standard_project'
                            logger.debug(f"Move {move_number}: Detected standard project")
                        elif action_type == 'other' and 'passes' in log_msg.lower():
                            action_type = 'pass'
                            logger.debug(f"Move {move_number}: Detected pass")
                        elif action_type == 'other' and 'skips second action' in log_msg.lower():
                            action_type = 'skip_action'
                            logger.debug(f"Move {move_number}: Detected skip second action")
                    
                    elif item_type == 'undoMove':
                        # Use undo label only as fallback when action not yet determined
                        label = args.get('label', '')
                        if label == 'draw' and action_type == 'other':
                            action_type = 'draw'
                            logger.debug(f"Move {move_number}: Confirmed draw action from undo label")
                        elif label == 'play' and action_type == 'other':
                            action_type = 'play_card'
                            logger.debug(f"Move {move_number}: Confirmed play card from undo label")
            
            # Fallback sell detection for older format (no reason_tr)
            if action_type == 'other' and has_discard_hidden and has_m_gain_action:
                action_type = 'sell_cards'
                reason = 'Sell patents'
                logger.debug(f"Move {move_number}: Detected sell patents via fallback (discard + M€ gain)")

            return action_type, card_played, tile_placed, tile_location, reason

        except Exception as e:
            logger.error(f"Error extracting action details from gamelogs for move {move_number}: {e}")
            return 'other', None, None, None, None
    
    def _extract_hand_from_gamelogs(self, move_number: int, gamelogs: Dict[str, Any], card_names_map: Dict[str, str] = None) -> Optional[Tuple[str, List[str]]]:
        """Extract a player's hand cards from gamelogs for a given move.

        Looks at 'card' and 'sell' operations in gameStateChange events.
        Uses the 'info' dict keys (full hand) rather than 'target' (playable subset).
        The owning player is identified via 'active_player' on the gameStateChange.

        Returns:
            Tuple of (player_id, hand_card_names) or None if no hand found.
        """
        if not gamelogs:
            return None
        try:
            data_entries = gamelogs.get('data', {}).get('data', [])
            hand_ids: Optional[List[str]] = None
            hand_player_id: Optional[str] = None

            for entry in data_entries:
                if entry.get('move_id') != str(move_number):
                    continue
                for item in entry.get('data', []):
                    if not isinstance(item, dict):
                        continue
                    if item.get('type') != 'gameStateChange':
                        continue

                    args = item.get('args') or {}
                    inner = args.get('args', {})
                    if not isinstance(inner, dict):
                        continue

                    active_player = str(inner.get('active_player', args.get('active_player', '')))

                    ops = inner.get('operations', {})
                    if not isinstance(ops, dict):
                        continue

                    for op in ops.values():
                        if not isinstance(op, dict):
                            continue
                        op_type = op.get('type') or op.get('typeexpr')
                        if op_type not in ('card', 'sell'):
                            continue
                        op_args = op.get('args') or {}
                        # Prefer info keys (full hand including unplayable cards)
                        info = op_args.get('info', {})
                        if isinstance(info, dict) and info:
                            cards = sorted(k for k in info if isinstance(k, str) and k.startswith('card_main_'))
                            if cards:
                                hand_ids = cards
                                hand_player_id = active_player
                                break
                        # Fall back to target (e.g. sell operation has empty info)
                        target = op_args.get('target', [])
                        if isinstance(target, list) and target:
                            cards = sorted(t for t in target if isinstance(t, str) and t.startswith('card_main_'))
                            if cards:
                                hand_ids = cards
                                hand_player_id = active_player
                                break
                    if hand_ids is not None:
                        break

            if hand_ids is None or not hand_player_id:
                return None

            hand_names = [
                card_names_map[cid] if card_names_map and cid in card_names_map else cid
                for cid in hand_ids
            ]
            return (hand_player_id, hand_names)
        except Exception:
            return None

    def _classify_action_type(self, log_entries: List[Tag], description: str) -> str:
        """Classify the type of action (fallback method)"""
        if 'plays card' in description:
            return 'play_card'
        elif any(phrase in description for phrase in ['places City', 'places Forest', 'places Ocean']):
            return 'place_tile'
        elif 'standard project' in description:
            return 'standard_project'
        elif 'passes' in description:
            return 'pass'
        elif 'Convert heat into temperature' in description:
            return 'convert_heat'
        elif 'claims milestone' in description:
            return 'claim_milestone'
        elif 'funds' in description and 'award' in description:
            return 'fund_award'
        elif 'activates' in description:
            return 'activate_card'
        elif 'New generation' in description:
            return 'new_generation'
        elif 'draft' in description:
            return 'draft'
        elif 'Buy Card' in description:
            return 'buy_card'
        elif 'draws' in description and 'cards' in description:
            return 'draw'
        else:
            return 'other'
    
    def _extract_card_played(self, log_entries: List[Tag]) -> Optional[str]:
        """Extract the name of the card played"""
        for entry in log_entries:
            text = entry.get_text()
            if 'plays card' in text:
                card_link = entry.find('div', class_='card_hl_tt')
                if card_link:
                    return card_link.get_text().strip()
                else:
                    # Fallback: extract from text
                    match = re.search(r'plays card (.+)', text)
                    if match:
                        return match.group(1).strip()
        return None
    
    def _extract_tile_placement(self, log_entries: List[Tag]) -> Tuple[Optional[str], Optional[str]]:
        """Extract tile placement information"""
        for entry in log_entries:
            text = entry.get_text()
            if 'places' in text:
                if 'places City on' in text:
                    tile_type = "City"
                    location_match = re.search(r'places City on (.+)', text)
                elif 'places Forest on' in text:
                    tile_type = "Forest"
                    location_match = re.search(r'places Forest on (.+)', text)
                elif 'places Ocean on' in text:
                    tile_type = "Ocean"
                    location_match = re.search(r'places Ocean on (.+)', text)
                else:
                    continue
                
                location = location_match.group(1).strip() if location_match else "Unknown"
                return tile_type, location
        
        return None, None
    
    def _extract_parameter_changes_from_gamelogs(self, gamelogs: Dict[str, Any]) -> Dict[int, Dict[str, int]]:
        """Extract terraforming parameter changes from gamelogs JSON data"""
        parameter_changes_by_move = {}
        
        try:
            data_entries = gamelogs.get('data', {}).get('data', [])
            
            for entry in data_entries:
                if not isinstance(entry, dict):
                    continue
                
                move_id = entry.get('move_id')
                if not move_id:
                    continue
                
                try:
                    move_number = int(move_id)
                except (ValueError, TypeError):
                    continue
                
                # Process all data items in this move
                entry_data = entry.get('data', [])
                if not isinstance(entry_data, list):
                    continue
                
                move_changes = {}
                
                for data_item in entry_data:
                    if not isinstance(data_item, dict):
                        continue
                    
                    # Look for counter updates with global parameter trackers
                    if data_item.get('type') == 'counter':
                        args = data_item.get('args', {})
                        # For generation, use counter_name; for others, use token_name from token_div_count
                        counter_name = args.get('counter_name', '')
                        token_div_count = args.get('token_div_count', {})
                        token_name = token_div_count.get('args', {}).get('token_name', '') if isinstance(token_div_count, dict) else ''
                        counter_value = args.get('counter_value')
                        
                        if counter_value is not None:
                            try:
                                value = int(counter_value)
                                
                                # Map tracker names to parameters - check both counter_name and token_name
                                tracker_name = counter_name or token_name
                                if tracker_name == 'tracker_gen':  # Generation
                                    move_changes['generation'] = value
                                    logger.info(f"Move {move_number}: Found generation = {value}")
                                elif tracker_name == 'tracker_t':  # Temperature
                                    move_changes['temperature'] = value
                                    logger.debug(f"Move {move_number}: Found temperature = {value}")
                                elif tracker_name == 'tracker_o':  # Oxygen
                                    move_changes['oxygen'] = value
                                    logger.debug(f"Move {move_number}: Found oxygen = {value}")
                                elif tracker_name == 'tracker_w':  # Oceans
                                    move_changes['oceans'] = value
                                    logger.debug(f"Move {move_number}: Found oceans = {value}")
                                    
                            except (ValueError, TypeError):
                                continue
                
                # Store changes for this move if any were found
                if move_changes:
                    parameter_changes_by_move[move_number] = move_changes
                    logger.debug(f"Move {move_number}: Parameter changes = {move_changes}")
            
            logger.info(f"Extracted parameter changes for {len(parameter_changes_by_move)} moves from gamelogs")
            return parameter_changes_by_move
            
        except Exception as e:
            logger.error(f"Error extracting parameter changes from gamelogs: {e}")
            return {}
    
    def _update_player_data_from_move(self, move: Move, players_info: Dict[str, Player]):
        """Update player data based on move information"""
        if move.player_id not in players_info:
            return
        
        player = players_info[move.player_id]
        
        # Track cards played
        if move.card_played:
            player.cards_played.append(move.card_played)
        
        # Track milestones claimed
        if move.action_type == 'claim_milestone':
            milestone_match = re.search(r'claims milestone (\w+)', move.description)
            if milestone_match:
                player.milestones_claimed.append(milestone_match.group(1))
        
        # Track awards funded
        if move.action_type == 'fund_award':
            award_match = re.search(r'funds (\w+) award', move.description)
            if award_match:
                player.awards_funded.append(award_match.group(1))
    
    def _build_game_states(self, moves: List[Move], vp_progression: List[Dict[str, Any]], players_info: Dict[str, Player], gamelogs: Dict[str, Any] = None) -> List[Move]:
        """Build game states for each move with VP, milestone, and award tracking"""
        # Initialize tracking variables
        current_temp = -30
        current_oxygen = 0
        current_oceans = 0
        current_generation = 1
        
        # Track milestones and awards state throughout the game
        current_milestones = {}
        current_awards = {}
        
        # Initialize default VP data for all players
        default_vp_data = {}
        for player_id in players_info.keys():
            default_vp_data[player_id] = {
                "total": 20,
                "total_details": {
                    "tr": 20,
                    "awards": 0,
                    "milestones": 0,
                    "cities": 0,
                    "greeneries": 0,
                    "cards": 0
                }
            }
        
        # Track the last known VP data to carry forward when no new data is available
        last_vp_data = dict(default_vp_data)
        
        # Create a mapping from move_number to VP data for proper correlation
        vp_by_move_number = {}
        for vp_entry in vp_progression:
            move_number = vp_entry.get('move_number')
            if move_number:
                # Convert move_number to string for consistent matching
                vp_by_move_number[str(move_number)] = vp_entry.get('vp_data', {})
        
        logger.info(f"Built VP mapping for {len(vp_by_move_number)} moves")
        
        # Extract parameter changes from gamelogs if available
        parameter_changes_by_move = {}
        if gamelogs:
            parameter_changes_by_move = self._extract_parameter_changes_from_gamelogs(gamelogs)
            logger.info(f"Extracted parameter changes for {len(parameter_changes_by_move)} moves from gamelogs")
        
        # Process each move and build game state
        for i, move in enumerate(moves):
            # Update parameters from gamelogs data
            move_parameter_changes = parameter_changes_by_move.get(move.move_number, {})
            if move_parameter_changes:
                if 'temperature' in move_parameter_changes:
                    current_temp = move_parameter_changes['temperature']
                    logger.debug(f"Move {move.move_number}: Temperature updated to {current_temp}")
                if 'oxygen' in move_parameter_changes:
                    current_oxygen = move_parameter_changes['oxygen']
                    logger.debug(f"Move {move.move_number}: Oxygen updated to {current_oxygen}")
                if 'oceans' in move_parameter_changes:
                    current_oceans = move_parameter_changes['oceans']
                    logger.debug(f"Move {move.move_number}: Oceans updated to {current_oceans}")
                if 'generation' in move_parameter_changes:
                    current_generation = move_parameter_changes['generation']
                    logger.debug(f"Move {move.move_number}: Generation updated to {current_generation}")
                    logger.debug(f"Move {move.move_number}: Generation updated to {current_generation}")
            
            # Update milestone and award tracking
            if move.action_type == 'claim_milestone':
                milestone_match = re.search(r'claims milestone (\w+)', move.description)
                if milestone_match:
                    milestone_name = milestone_match.group(1)
                    current_milestones[milestone_name] = {
                        'claimed_by': move.player_name,
                        'player_id': move.player_id,
                        'move_number': move.move_number,
                        'timestamp': move.timestamp
                    }
            
            if move.action_type == 'fund_award':
                award_match = re.search(r'funds (\w+) award', move.description)
                if award_match:
                    award_name = award_match.group(1)
                    current_awards[award_name] = {
                        'funded_by': move.player_name,
                        'player_id': move.player_id,
                        'move_number': move.move_number,
                        'timestamp': move.timestamp
                    }
            
            # Get VP data for this move by matching move_number
            move_vp_data = vp_by_move_number.get(str(move.move_number), {})
            
            # Ensure VP data is always present
            if move_vp_data:
                # Update last known VP data with new data
                last_vp_data = dict(move_vp_data)
                logger.debug(f"Updated VP data for move {move.move_number}")
            else:
                # Use last known VP data if no new data available
                move_vp_data = dict(last_vp_data)
                logger.debug(f"Using carried-forward VP data for move {move.move_number}")
            
            # Ensure all players have VP data (fill in missing players with defaults)
            for player_id in players_info.keys():
                if player_id not in move_vp_data:
                    move_vp_data[player_id] = dict(default_vp_data[player_id])
                    logger.debug(f"Added default VP data for missing player {player_id} in move {move.move_number}")
            
            # Create game state (without resource/production tracking)
            game_state = GameState(
                move_number=move.move_number,
                generation=current_generation,
                temperature=current_temp,
                oxygen=current_oxygen,
                oceans=current_oceans,
                player_vp=move_vp_data,
                milestones=dict(current_milestones),
                awards=dict(current_awards)
            )
            
            move.game_state = game_state
        
        return moves
    
    def _extract_card_names(self, html_content: str) -> Dict[str, str]:
        """Extract card ID to name mappings from HTML"""
        card_names = {}
        
        try:
            # Pattern to match card elements with data-name attributes
            pattern = r'<div[^>]+id="(card_[^"]+)"[^>]+data-name="([^"]+)"'
            matches = re.findall(pattern, html_content)
            
            for card_id, card_name in matches:
                # Clean up the card ID (remove _help suffix if present)
                clean_id = card_id.replace('_help', '')
                card_names[clean_id] = card_name
            
            logger.info(f"Extracted {len(card_names)} card name mappings")
            return card_names
            
        except Exception as e:
            logger.error(f"Error extracting card names: {e}")
            return {}
    
    def _extract_milestone_names(self, html_content: str) -> Dict[str, str]:
        """Extract milestone ID to name mappings from HTML"""
        milestone_names = {}
        
        try:
            # Pattern to match milestone elements with data-name attributes
            pattern = r'<div[^>]+id="(milestone_\d+)"[^>]+data-name="([^"]+)"'
            matches = re.findall(pattern, html_content)
            
            for milestone_id, milestone_name in matches:
                milestone_names[milestone_id] = milestone_name
            
            logger.info(f"Extracted {len(milestone_names)} milestone name mappings")
            return milestone_names
            
        except Exception as e:
            logger.error(f"Error extracting milestone names: {e}")
            return {}
    
    def _extract_award_names(self, html_content: str) -> Dict[str, str]:
        """Extract award ID to name mappings from HTML"""
        award_names = {}
        
        try:
            # Pattern to match award elements with data-name attributes
            pattern = r'<div[^>]+id="(award_\d+)"[^>]+data-name="([^"]+)"'
            matches = re.findall(pattern, html_content)
            
            for award_id, award_name in matches:
                award_names[award_id] = award_name
            
            logger.info(f"Extracted {len(award_names)} award name mappings")
            return award_names
            
        except Exception as e:
            logger.error(f"Error extracting award names: {e}")
            return {}

    def _extract_hex_names(self, html_content: str) -> Dict[str, str]:
        """Extract hex ID to name mappings from HTML hex map"""
        hex_names = {}
        
        try:
            # Pattern to match hex elements with data-name attributes
            pattern = r'<div[^>]+id="(hex_\d+_\d+)"[^>]+data-name="([^"]+)"'
            matches = re.findall(pattern, html_content)
            
            for hex_id, hex_name in matches:
                hex_names[hex_id] = hex_name
            
            logger.info(f"Extracted {len(hex_names)} hex name mappings")
            return hex_names
            
        except Exception as e:
            logger.error(f"Error extracting hex names: {e}")
            return {}

    def _extract_tile_to_hex_mapping(self, gamelogs: Dict[str, Any]) -> Dict[str, str]:
        """Extract tile ID to hex ID mappings from gamelogs"""
        tile_to_hex = {}
        
        try:
            data_entries = gamelogs.get('data', {}).get('data', [])
            
            for entry in data_entries:
                if not isinstance(entry, dict):
                    continue
                
                entry_data = entry.get('data', [])
                if not isinstance(entry_data, list):
                    continue
                
                for data_item in entry_data:
                    if not isinstance(data_item, dict):
                        continue
                    
                    # Look for tile placement events
                    args = data_item.get('args', {})
                    if 'token_id' in args and 'place_id' in args:
                        token_id = args['token_id']
                        place_id = args['place_id']
                        
                        # Only map tile tokens to hex places
                        if token_id.startswith('tile_') and place_id.startswith('hex_'):
                            tile_to_hex[token_id] = place_id
                            logger.debug(f"Mapped tile {token_id} to hex {place_id}")
            
            logger.info(f"Extracted {len(tile_to_hex)} tile-to-hex mappings")
            return tile_to_hex
            
        except Exception as e:
            logger.error(f"Error extracting tile-to-hex mapping: {e}")
            return {}

    def _extract_g_gamelogs(self, html_content: str) -> Dict[str, Any]:
        """Extract g_gamelogs JSON with proper brace balancing"""
        try:
            # Find the start of g_gamelogs
            pattern = r'g_gamelogs\s*=\s*'
            match = re.search(pattern, html_content)
            
            if not match:
                logger.warning("g_gamelogs not found in HTML")
                return {}
            
            start_pos = match.end()
            
            # Find the complete JSON object by counting braces
            brace_count = 0
            in_string = False
            escape_next = False
            
            for i, char in enumerate(html_content[start_pos:], start_pos):
                if escape_next:
                    escape_next = False
                    continue
                    
                if char == '\\':
                    escape_next = True
                    continue
                    
                if char == '"' and not escape_next:
                    in_string = not in_string
                    continue
                    
                if not in_string:
                    if char == '{':
                        brace_count += 1
                    elif char == '}':
                        brace_count -= 1
                        if brace_count == 0:
                            # Found the end of the JSON object
                            json_str = html_content[start_pos:i+1]
                            return json.loads(json_str)
                    elif char == ';' and brace_count == 0:
                        # Hit semicolon before closing brace - malformed
                        break
            
            logger.error("Could not find complete g_gamelogs JSON")
            return {}
            
        except (json.JSONDecodeError, AttributeError) as e:
            logger.error(f"Error extracting g_gamelogs: {e}")
            return {}
    
    def _extract_token_types(self, html_content: str) -> Dict[str, Any]:
        """
        Extract the token_types object embedded in the game setup payload.
        
        Strategy:
          1) Prefer extracting the full config object passed to gameui.completesetup(..., { ... }, ...)
             and then return its "token_types" property.
          2) Fallback to extracting the object that follows the "token_types": key directly.
        """
        try:
            # Helper: extract a balanced-brace object starting at a given '{' index
            def extract_balanced_object(s: str, start_idx: int) -> str:
                brace_count = 0
                in_string = False
                escape_next = False
                for i in range(start_idx, len(s)):
                    ch = s[i]
                    if escape_next:
                        escape_next = False
                        continue
                    if ch == '\\':
                        escape_next = True
                        continue
                    if ch == '"' and not escape_next:
                        in_string = not in_string
                        continue
                    if not in_string:
                        if ch == '{':
                            brace_count += 1
                        elif ch == '}':
                            brace_count -= 1
                            if brace_count == 0:
                                return s[start_idx:i+1]
                raise ValueError("Unbalanced braces when extracting object")

            # 1) Primary path: find gameui.completesetup(...)
            setup_match = re.search(r'gameui\.completesetup\s*\(', html_content)
            if setup_match:
                # Find the first '{' after the opening parenthesis – this should begin the big config object
                search_from = setup_match.end()
                brace_start = html_content.find('{', search_from)
                if brace_start != -1:
                    try:
                        obj_str = extract_balanced_object(html_content, brace_start)
                        payload = json.loads(obj_str)
                        token_types = payload.get('token_types', {})
                        if isinstance(token_types, dict):
                            logger.info(f"Extracted token_types with {len(token_types)} entries from completesetup payload")
                            return token_types
                        else:
                            logger.warning("token_types present but not a dict")
                    except (json.JSONDecodeError, ValueError) as e:
                        logger.warning(f"Failed to parse completesetup payload JSON, trying fallback: {e}")

            # 2) Fallback: find the token_types block directly
            tt_key = re.search(r'"token_types"\s*:\s*\{', html_content)
            if tt_key:
                brace_start = html_content.find('{', tt_key.start())
                if brace_start != -1:
                    try:
                        tt_obj_str = extract_balanced_object(html_content, brace_start)
                        # token_types value itself is a JSON object – parse and return
                        token_types = json.loads(tt_obj_str)
                        if isinstance(token_types, dict):
                            logger.info(f"Extracted token_types directly with {len(token_types)} entries")
                            return token_types
                    except (json.JSONDecodeError, ValueError) as e:
                        logger.error(f"Error parsing token_types object directly: {e}")
                        return {}

            logger.warning("token_types not found in HTML")
            return {}
            
        except Exception as e:
            logger.error(f"Error extracting token_types: {e}")
            return {}
    
    def _extract_card_names_from_token_types(self, token_types: Dict[str, Any]) -> Dict[str, str]:
        """
        Extract card ID to name mappings from token_types JSON structure.
        
        Filters for actual cards (excludes standard projects and colonies):
        - Includes: card_main_*, card_prelude_*, card_corp_*
        - Excludes: card_stanproj_*, card_colo_*
        
        Args:
            token_types: The token_types dictionary from game setup
            
        Returns:
            dict: Card ID -> Card Name mapping
        """
        card_names = {}
        
        try:
            # Define patterns for cards we want to include
            include_patterns = [
                r'^card_main_',
                r'^card_prelude_',
                r'^card_corp_'
            ]
            
            # Define patterns for cards we want to exclude
            exclude_patterns = [
                r'^card_stanproj_',
                r'^card_colo_'
            ]
            
            for token_id, token_data in token_types.items():
                # Check if this is a card token
                if not token_id.startswith('card_'):
                    continue
                
                # Check if it matches any exclude patterns
                should_exclude = False
                for exclude_pattern in exclude_patterns:
                    if re.match(exclude_pattern, token_id):
                        should_exclude = True
                        break
                
                if should_exclude:
                    logger.debug(f"Excluding card token: {token_id}")
                    continue
                
                # Check if it matches any include patterns
                should_include = False
                for include_pattern in include_patterns:
                    if re.match(include_pattern, token_id):
                        should_include = True
                        break
                
                if not should_include:
                    logger.debug(f"Card token doesn't match include patterns: {token_id}")
                    continue
                
                # Extract the card name
                if isinstance(token_data, dict) and 'name' in token_data:
                    card_name = token_data['name']
                    if isinstance(card_name, str) and card_name.strip():
                        card_names[token_id] = card_name.strip()
                        logger.debug(f"Extracted card: {token_id} -> {card_name}")
                    else:
                        logger.warning(f"Card {token_id} has invalid name: {card_name}")
                else:
                    logger.warning(f"Card {token_id} missing name property or invalid structure")
            
            logger.info(f"Extracted {len(card_names)} card names from token_types")
            return card_names
            
        except Exception as e:
            logger.error(f"Error extracting card names from token_types: {e}")
            return {}
    
    def _replace_ids_with_names(self, vp_data: Dict[str, Any], card_names: Dict[str, str], 
                               milestone_names: Dict[str, str], award_names: Dict[str, str],
                               tile_to_hex: Dict[str, str] = None, hex_names: Dict[str, str] = None) -> Dict[str, Any]:
        """Replace ID references with actual names in VP data, including hex information for tiles"""
        if not isinstance(vp_data, dict):
            return vp_data
        
        # Default to empty dicts if not provided
        if tile_to_hex is None:
            tile_to_hex = {}
        if hex_names is None:
            hex_names = {}
        
        updated_data = {}
        
        for player_id, player_vp in vp_data.items():
            if not isinstance(player_vp, dict):
                updated_data[player_id] = player_vp
                continue
            
            updated_player_vp = dict(player_vp)
            
            # Process the details section
            if 'details' in updated_player_vp and isinstance(updated_player_vp['details'], dict):
                details = updated_player_vp['details']
                updated_details = {}
                
                for category, items in details.items():
                    # Skip TR category since it's already in total_details
                    if category == 'tr':
                        continue
                        
                    if not isinstance(items, dict):
                        updated_details[category] = items
                        continue
                    
                    updated_items = {}
                    
                    for item_id, item_data in items.items():
                        # Determine the actual name based on category and ID
                        actual_name = item_id  # Default to original ID
                        
                        if category == 'cards' and item_id in card_names:
                            actual_name = card_names[item_id]
                        elif category == 'milestones' and item_id in milestone_names:
                            actual_name = milestone_names[item_id]
                        elif category == 'awards' and item_id in award_names:
                            actual_name = award_names[item_id]
                        
                        # Handle tile placement data (cities, greeneries, etc.)
                        updated_item_data = dict(item_data) if isinstance(item_data, dict) else item_data
                        
                        if category in ['cities', 'greeneries'] and item_id.startswith('tile_'):
                            # Use hex name as the key instead of tile ID
                            hex_id = tile_to_hex.get(item_id)
                            if hex_id:
                                hex_name = hex_names.get(hex_id)
                                if hex_name:
                                    actual_name = hex_name
                                    logger.debug(f"Mapped tile {item_id} to hex name: {hex_name}")
                                else:
                                    # Format unnamed hex as coordinates (hex_4_8 -> "Hex 4,8")
                                    coords_match = re.match(r'hex_(\d+)_(\d+)', hex_id)
                                    if coords_match:
                                        actual_name = f"Hex {coords_match.group(1)},{coords_match.group(2)}"
                        
                        updated_items[actual_name] = updated_item_data
                    
                    updated_details[category] = updated_items
                
                updated_player_vp['details'] = updated_details
            
            updated_data[player_id] = updated_player_vp
        
        return updated_data

    def _parse_scoring_data_from_gamelogs(self, gamelogs: Dict[str, Any], card_names: Dict[str, str], 
                                        milestone_names: Dict[str, str], award_names: Dict[str, str]) -> List[Dict[str, Any]]:
        """Parse scoring data from g_gamelogs entries and replace IDs with names"""
        scoring_entries = []
        
        try:
            # Extract hex mappings for tile placement data
            hex_names = self._extract_hex_names_from_gamelogs_context(gamelogs)
            tile_to_hex = self._extract_tile_to_hex_mapping(gamelogs)
            
            data_entries = gamelogs.get('data', {}).get('data', [])
            
            for entry in data_entries:
                if not isinstance(entry, dict):
                    continue
                
                # Look for data array within each entry
                entry_data = entry.get('data', [])
                if not isinstance(entry_data, list):
                    continue
                
                for data_item in entry_data:
                    if not isinstance(data_item, dict):
                        continue
                    
                    # Look for scoringTable type entries
                    if data_item.get('type') == 'scoringTable':
                        scoring_data = data_item.get('args', {}).get('data', {})

                        if not scoring_data:
                            scoring_data = data_item.get('args', {}) # Older format

                        if scoring_data:
                            # Replace IDs with names in the scoring data, including hex information
                            scoring_data_with_names = self._replace_ids_with_names(
                                scoring_data, card_names, milestone_names, award_names,
                                tile_to_hex, hex_names
                            )
                            
                            scoring_entry = {
                                'move_id': entry.get('move_id'),
                                'time': entry.get('time'),
                                'uid': data_item.get('uid'),
                                'scoring_data': scoring_data_with_names
                            }
                            scoring_entries.append(scoring_entry)
            
            logger.info(f"Extracted {len(scoring_entries)} scoring entries from g_gamelogs")
            return scoring_entries
            
        except Exception as e:
            logger.error(f"Error parsing scoring data from g_gamelogs: {e}")
            return []

    def _extract_hex_names_from_gamelogs_context(self, gamelogs: Dict[str, Any]) -> Dict[str, str]:
        """Extract hex names from the context where gamelogs are used (fallback method)"""
        # This is a placeholder method - in practice, hex names should be extracted from HTML
        # This method exists to maintain consistency when gamelogs are processed separately
        return {}

    def _extract_vp_progression(self, html_content: str, gamelogs: Dict[str, Any], token_types: Dict[str, Any] = None) -> List[Dict[str, Any]]:
        """Extract VP progression throughout the game using g_gamelogs data"""

        # Extract name mappings from HTML
        card_names = self._extract_card_names(html_content)
        milestone_names = self._extract_milestone_names(html_content)
        award_names = self._extract_award_names(html_content)
        hex_names = self._extract_hex_names(html_content)

        # Fallback to token_types for any missing name mappings
        if token_types:
            if not card_names:
                card_names = self._extract_card_names_from_token_types(token_types)
            for token_id, token_data in token_types.items():
                if not isinstance(token_data, dict):
                    continue
                name = token_data.get('name') or token_data.get('tooltip_action')
                if not isinstance(name, str) or not name.strip():
                    continue
                if token_id.startswith('milestone_') and token_id not in milestone_names:
                    milestone_names[token_id] = name.strip()
                elif token_id.startswith('award_') and token_id not in award_names:
                    award_names[token_id] = name.strip()
                elif token_id.startswith('hex_') and token_id not in hex_names:
                    hex_names[token_id] = name.strip()

        # Extract tile-to-hex mapping from gamelogs
        tile_to_hex = self._extract_tile_to_hex_mapping(gamelogs)

        # Parse scoring data from g_gamelogs with name replacement including hex information
        scoring_entries = self._parse_scoring_data_from_gamelogs_with_hex(
            gamelogs, card_names, milestone_names, award_names, tile_to_hex, hex_names
        )
        
        vp_progression = []
        for i, entry in enumerate(scoring_entries):
            scoring_data = entry['scoring_data']
            
            # Calculate combined total
            combined_total = sum(data.get('total', 0) for data in scoring_data.values())
            
            vp_entry = {
                'move_number': entry.get('move_id'),
                'time': entry.get('time'),
                'combined_total': combined_total,
                'vp_data': scoring_data
            }
            
            vp_progression.append(vp_entry)
        
        logger.info(f"Extracted VP progression with {len(vp_progression)} entries")
        return vp_progression

    def _parse_scoring_data_from_gamelogs_with_hex(self, gamelogs: Dict[str, Any], card_names: Dict[str, str], 
                                                  milestone_names: Dict[str, str], award_names: Dict[str, str],
                                                  tile_to_hex: Dict[str, str], hex_names: Dict[str, str]) -> List[Dict[str, Any]]:
        """Parse scoring data from g_gamelogs entries with hex information included"""
        scoring_entries = []
        
        try:
            data_entries = gamelogs.get('data', {}).get('data', [])
            
            for entry in data_entries:
                if not isinstance(entry, dict):
                    continue
                
                # Look for data array within each entry
                entry_data = entry.get('data', [])
                if not isinstance(entry_data, list):
                    continue
                
                for data_item in entry_data:
                    if not isinstance(data_item, dict):
                        continue
                    
                    # Look for scoringTable type entries
                    if data_item.get('type') == 'scoringTable':

                        scoring_data = data_item.get('args', {}).get('data', {})

                        if not scoring_data:
                            scoring_data = data_item.get('args', {})

                        if scoring_data:
                            # Replace IDs with names in the scoring data, including hex information
                            scoring_data_with_names = self._replace_ids_with_names(
                                scoring_data, card_names, milestone_names, award_names,
                                tile_to_hex, hex_names
                            )
                            
                            scoring_entry = {
                                'move_id': entry.get('move_id'),
                                'time': entry.get('time'),
                                'uid': data_item.get('uid'),
                                'scoring_data': scoring_data_with_names
                            }
                            scoring_entries.append(scoring_entry)
            
            logger.info(f"Extracted {len(scoring_entries)} scoring entries with hex information from g_gamelogs")
            return scoring_entries
            
        except Exception as e:
            logger.error(f"Error parsing scoring data with hex information from g_gamelogs: {e}")
            return []
    
    def _extract_vp_progression_fallback(self, html_content: str) -> List[Dict[str, Any]]:
        """Fallback VP progression extraction using the old regex method"""
        pattern = r'"data":\{((?:"(\d+)":\{[^}]*"total":(\d+)[^}]*\}[,\s]*)+)\}'
        
        matches = re.findall(pattern, html_content, re.DOTALL)
        vp_progression = []
        
        for i, match_data in enumerate(matches):
            try:
                json_str = "{" + match_data[0] + "}"
                
                # Fix JSON structure if needed
                brace_count = match_data[0].count('{') - match_data[0].count('}')
                if brace_count > 0:
                    json_str = "{" + match_data[0] + '}' * brace_count + "}"
                
                vp_data = json.loads(json_str)
                
                # Calculate combined total
                combined_total = sum(data.get('total', 0) for data in vp_data.values())
                
                vp_entry = {
                    'move_number': i + 1,  # Convert 0-based index to 1-based move number
                    'combined_total': combined_total,
                    'vp_data': vp_data
                }
                
                vp_progression.append(vp_entry)
                
            except json.JSONDecodeError:
                continue
        
        return vp_progression
    
    def _extract_vp_data_from_html(self, html_content: str) -> Dict[str, Any]:
        """Extract VP data from HTML - handles both newer and older formats with variable player counts"""
        logger.debug("Extracting VP data from HTML")
        
        # Try newer format first (with "data" wrapper in scoringTable)
        newer_pattern = r'"type":"scoringTable"[^}]*?"args":\s*\{\s*"data":\s*(\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\})'
        matches = re.findall(newer_pattern, html_content, re.DOTALL)
        
        if matches:
            logger.debug(f"Found {len(matches)} matches with newer format")
            # Try to parse each match and find the one with highest total VP
            best_vp_data = None
            best_total = 0
            
            for match in matches:
                try:
                    vp_data = json.loads(match)
                    # Calculate total VP across all players
                    total_vp = sum(player_data.get('total', 0) for player_data in vp_data.values() if isinstance(player_data, dict))
                    
                    if total_vp > best_total:
                        best_total = total_vp
                        best_vp_data = vp_data
                        logger.debug(f"Found better VP data with total {total_vp}")
                        
                except json.JSONDecodeError as e:
                    logger.debug(f"Failed to parse newer format match: {e}")
                    continue
            
            if best_vp_data:
                logger.info(f"Successfully extracted VP data (newer format) for {len(best_vp_data)} players, total VP: {best_total}")
                return best_vp_data
        
        # Try older format (direct player data in scoringTable args)
        older_pattern = r'"type":"scoringTable"[^}]*?"args":\s*(\{"[0-9]+":.*?\})'
        matches = re.findall(older_pattern, html_content, re.DOTALL)
        
        if matches:
            logger.debug(f"Found {len(matches)} matches with older format")
            # Try to parse each match and find the one with highest total VP
            best_vp_data = None
            best_total = 0
            
            for match in matches:
                try:
                    # Need to properly close the JSON - find the end of the player data
                    # Look for the complete args object
                    args_start = html_content.find(match)
                    if args_start == -1:
                        continue
                    
                    # Find the closing brace for the args object
                    brace_count = 0
                    end_pos = args_start
                    in_string = False
                    escape_next = False
                    
                    for i, char in enumerate(html_content[args_start:], args_start):
                        if escape_next:
                            escape_next = False
                            continue
                            
                        if char == '\\':
                            escape_next = True
                            continue
                            
                        if char == '"' and not escape_next:
                            in_string = not in_string
                            continue
                            
                        if not in_string:
                            if char == '{':
                                brace_count += 1
                            elif char == '}':
                                brace_count -= 1
                                if brace_count == 0:
                                    end_pos = i + 1
                                    break
                    
                    # Extract the complete JSON
                    complete_json = html_content[args_start:end_pos]
                    vp_data = json.loads(complete_json)
                    
                    # Calculate total VP across all players
                    total_vp = sum(player_data.get('total', 0) for player_data in vp_data.values() if isinstance(player_data, dict))
                    
                    if total_vp > best_total:
                        best_total = total_vp
                        best_vp_data = vp_data
                        logger.debug(f"Found better VP data with total {total_vp}")
                        
                except json.JSONDecodeError as e:
                    logger.debug(f"Failed to parse older format match: {e}")
                    continue
            
            if best_vp_data:
                logger.info(f"Successfully extracted VP data (older format) for {len(best_vp_data)} players, total VP: {best_total}")
                return best_vp_data
        
        # Final fallback - try the original regex approach for backwards compatibility
        logger.debug("Trying original regex fallback")
        original_pattern = r'"data":\{("(\d+)":\{.*?"total":(\d+).*?\}.*?"(\d+)":\{.*?"total":(\d+).*?\})\}'
        matches = re.findall(original_pattern, html_content, re.DOTALL)
        
        if matches:
            best_match = None
            best_total = 0
            
            for match_data, player1_id, total1, player2_id, total2 in matches:
                combined_total = int(total1) + int(total2)
                if combined_total > best_total:
                    best_total = combined_total
                    best_match = match_data
            
            if best_match:
                try:
                    json_str = "{" + best_match + "}"
                    brace_count = best_match.count('{') - best_match.count('}')
                    if brace_count > 0:
                        json_str = "{" + best_match + '}' * brace_count + "}"
                    
                    result = json.loads(json_str)
                    logger.info(f"Successfully extracted VP data (fallback) for {len(result)} players")
                    return result
                except json.JSONDecodeError:
                    pass
        
        logger.warning("Failed to extract VP data from HTML using all methods")
        return {}
    
    def _extract_corporations(self, soup: BeautifulSoup, player_perspective: str, player_id_map: Dict[str, str]) -> Dict[str, str]:
        """Extract corporation assignments"""
        corporations = {}
        
        # Look for corporation mentions in the log
        log_entries = soup.find_all('div', class_='gamelogreview')
        for entry in log_entries:
            text = entry.get_text()
            if 'chooses corporation' in text:
                # This pattern is more robust and handles Unicode characters in player names.
                pattern = r'(.+?) chooses corporation ([A-Za-z][A-Za-z0-9\s]+)(?:\s*\||$)'
                match = re.search(pattern, text)
                if match:
                    player_name = match.group(1).strip()
                    corp_name = match.group(2).strip()
                    corporations[player_name] = corp_name
                    logger.info(f"Extracted corporation: {player_name} -> {corp_name}")

        # Fallback for player_perspective
        player_perspective_name = player_id_map.get(player_perspective)
        if player_perspective_name and player_perspective_name not in corporations:
            for entry in log_entries:
                text = entry.get_text()
                if 'You choose corporation' in text:
                    pattern = r"You choose corporation\s+([A-Za-z\s]+)"
                    match = re.search(pattern, text)
                    if match:
                        corp_name = match.group(1).strip()
                        if '|' in corp_name:
                            corp_name = corp_name.split('|')[0].strip()
                        corporations[player_perspective_name] = corp_name
                        logger.info(f"Extracted corporation for player perspective ({player_perspective_name}): {corp_name}")
                        break
        
        logger.info(f"Total corporations extracted: {corporations}")
        return corporations
    
    def _calculate_game_duration(self, moves: List[Move]) -> str:
        """Calculate game duration from moves"""
        if not moves or len(moves) < 2:
            return "Unknown"
        
        try:
            start_time = moves[0].timestamp
            end_time = moves[-1].timestamp
            
            # Parse timestamps (assuming HH:MM:SS format)
            start_parts = start_time.split(':')
            end_parts = end_time.split(':')
            
            start_seconds = int(start_parts[0]) * 3600 + int(start_parts[1]) * 60 + int(start_parts[2])
            end_seconds = int(end_parts[0]) * 3600 + int(end_parts[1]) * 60 + int(end_parts[2])
            
            duration_seconds = end_seconds - start_seconds
            if duration_seconds < 0:  # Handle day rollover
                duration_seconds += 24 * 3600
            
            hours = duration_seconds // 3600
            minutes = (duration_seconds % 3600) // 60
            
            return f"{hours:02d}:{minutes:02d}"
            
        except (ValueError, IndexError):
            return "Unknown"
    
    def _calculate_max_generation(self, vp_progression: List[Dict[str, Any]], moves: List[Move]) -> int:
        """Calculate the maximum generation from vp_progression or moves data"""
        max_generation = 1  # Default to generation 1
        
        try:
            # First, try to get max generation from moves with game states
            if moves:
                generations_from_moves = []
                for move in moves:
                    if move.game_state and move.game_state.generation:
                        generations_from_moves.append(move.game_state.generation)
                
                if generations_from_moves:
                    max_generation = max(generations_from_moves)
                    logger.info(f"Found max generation {max_generation} from moves")
                    return max_generation
            
            # Fallback: try to extract from vp_progression data
            # This is less reliable but can be used if moves don't have generation data
            if vp_progression:
                # VP progression entries might contain generation information
                # This would need to be implemented based on the actual structure
                logger.info("Attempting to extract generation from vp_progression (fallback)")
                # For now, we'll use a simple heuristic based on the number of VP entries
                # In Terraforming Mars, games typically last 8-12 generations
                estimated_generations = min(12, max(8, len(vp_progression) // 2))
                max_generation = estimated_generations
                logger.info(f"Estimated max generation {max_generation} from vp_progression length")
            
        except Exception as e:
            logger.error(f"Error calculating max generation: {e}")
            max_generation = 1
        
        logger.info(f"Calculated max generation: {max_generation}")
        return max_generation

    def _extract_starting_hands_from_gamelogs(self, gamelogs: Dict[str, Any], token_types: Dict[str, Any]) -> Optional[Dict[str, StartingHand]]:
        """Extract starting hands for both players from gamelogs newPrivateState data"""
        logger.info("Extracting starting hands from gamelogs")
        
        try:
            starting_hands = {}
            data_entries = gamelogs.get('data', {}).get('data', [])
            
            for entry in data_entries:
                if not isinstance(entry, dict):
                    continue
                
                entry_data = entry.get('data', [])
                if not isinstance(entry_data, list):
                    continue
                
                for data_item in entry_data:
                    if not isinstance(data_item, dict):
                        continue
                    
                    # Look for newPrivateState type entries
                    if data_item.get('type') == 'newPrivateState':
                        # Extract player ID from channel
                        channel = entry.get('channel', '')
                        player_match = re.search(r'/player/p(\d+)', channel)
                        if not player_match:
                            continue
                        
                        player_id = player_match.group(1)
                        
                        # Navigate to player operations
                        args = data_item.get('args', {})
                        inner_args = args.get('args', {})
                        player_operations = inner_args.get('player_operations', {})
                        
                        if player_id not in player_operations:
                            continue
                        
                        player_ops = player_operations[player_id]
                        operations = player_ops.get('operations', {})
                        
                        # Look for setuppick operation
                        for op_id, operation in operations.items():
                            if not isinstance(operation, dict):
                                continue
                            
                            if operation.get('type') == 'setuppick' or operation.get('typeexpr') == 'setuppick':
                                op_args = operation.get('args', {})
                                target_list = op_args.get('target', [])
                                
                                if not isinstance(target_list, list):
                                    continue
                                
                                # Categorize cards by type
                                corporations = []
                                preludes = []
                                project_cards = []
                                
                                for token_id in target_list:
                                    if not isinstance(token_id, str):
                                        continue
                                    
                                    # Get card name from token_types
                                    token_data = token_types.get(token_id, {})
                                    card_name = token_data.get('name', token_id)
                                    
                                    # Categorize by token ID prefix
                                    if token_id.startswith('card_corp_'):
                                        corporations.append(card_name)
                                    elif token_id.startswith('card_prelude_'):
                                        preludes.append(card_name)
                                    elif token_id.startswith('card_main_'):
                                        project_cards.append(card_name)
                                    # Skip other types like card_stanproj_, card_colo_
                                
                                # Create starting hand for this player
                                starting_hand = StartingHand(
                                    corporations=corporations,
                                    preludes=preludes,
                                    project_cards=project_cards
                                )
                                
                                starting_hands[player_id] = starting_hand
                                logger.info(f"Extracted starting hand for player {player_id}: {len(corporations)} corps, {len(preludes)} preludes, {len(project_cards)} projects")
            
            if starting_hands:
                logger.info(f"Successfully extracted starting hands from gamelogs for {len(starting_hands)} players")
                return starting_hands
            else:
                logger.warning("No starting hands found in gamelogs")
                return None
                
        except Exception as e:
            logger.error(f"Error extracting starting hands from gamelogs: {e}")
            return None

    def _extract_starting_hands(self, soup: BeautifulSoup, player_perspective: str) -> Optional[Dict[str, StartingHand]]:
        """Extracts the starting hand for the player of perspective from the hand area (fallback method)."""
        logger.info("Extracting starting hands from HTML (fallback)")
        try:
            hand_area = soup.find('div', id='hand_area')
            if not hand_area:
                logger.warning("Hand area not found")
                return None

            corporations = []
            preludes = []
            project_cards = []

            cards = hand_area.find_all('div', class_='card')
            for card in cards:
                card_name = card.get('data-name')
                if not card_name:
                    continue

                card_id = card.get('id', '')
                if 'corp' in card_id:
                    corporations.append(card_name)
                    
                elif 'prelude' in card_id:
                    preludes.append(card_name)

                elif 'stanproj' in card_id:
                    continue

                else:
                    project_cards.append(card_name)
            
            player_hand = StartingHand(
                corporations=corporations,
                preludes=preludes,
                project_cards=project_cards
            )
            
            starting_hands = {player_perspective: player_hand}
            logger.info(f"Extracted starting hands from HTML: {starting_hands}")
            return starting_hands

        except Exception as e:
            logger.error(f"Error extracting starting hands from HTML: {e}")
            return None

    def _extract_metadata(self, soup: BeautifulSoup, html_content: str, moves: List[Move]) -> Dict[str, Any]:
        """Extract metadata about the parsing process"""
        # Calculate total moves as the maximum move_number
        total_moves = 0
        if moves:
            total_moves = max(move.move_number for move in moves)
        
        return {
            'parsed_at': datetime.now().isoformat(),
            'total_moves': total_moves
        }

    def _extract_tracker_dictionary_from_html(self, html_content: str) -> Dict[str, str]:
        """Dynamically extract all tracker mappings from HTML elements"""
        tracker_dict = {}
        
        try:
            logger.info("Starting tracker dictionary extraction...")
            
            # Method 1: Look for elements with data-name attributes
            patterns = [
                # Look for data-name attribute
                r'<[^>]*id="((?:tracker_|counter_)[^"]+)"[^>]*data-name="([^"]+)"[^>]*>',
                # Look for title attribute  
                r'<[^>]*id="((?:tracker_|counter_)[^"]+)"[^>]*title="([^"]+)"[^>]*>',
            ]
            
            for i, pattern in enumerate(patterns):
                matches = re.findall(pattern, html_content, re.IGNORECASE | re.DOTALL)
                logger.info(f"Pattern {i+1} found {len(matches)} matches")
                
                for tracker_id, display_name in matches:
                    if tracker_id and display_name:
                        tracker_dict[tracker_id] = display_name.strip()
            
            # Method 2: If we didn't get enough results, try aggressive extraction
            if len(tracker_dict) < 10:  # Expect more trackers in a typical game
                logger.info("Not enough trackers found, trying aggressive extraction...")
                
                # Find all tracker/counter IDs first
                id_pattern = r'id="((?:tracker_|counter_)[^"]+)"'
                all_ids = re.findall(id_pattern, html_content, re.IGNORECASE)
                logger.info(f"Found {len(all_ids)} tracker/counter IDs total")
                
                for tracker_id in all_ids:
                    if tracker_id not in tracker_dict:
                        # Try to find the display name by looking at the surrounding HTML
                        display_name = self._infer_display_name_from_context(tracker_id, html_content)
                        if display_name:
                            tracker_dict[tracker_id] = display_name
            
            logger.info(f"Extracted {len(tracker_dict)} tracker mappings dynamically from HTML")

            # Log some examples for debugging
            if tracker_dict:
                sample_items = list(tracker_dict.items())[:5]
                logger.info(f"Sample tracker mappings: {sample_items}")
            
            return tracker_dict
            
        except Exception as e:
            logger.error(f"Error extracting tracker dictionary: {e}")
            return {}

    def _infer_display_name_from_context(self, tracker_id: str, html_content: str) -> str:
        """Try to infer display name from surrounding HTML context"""
        try:
            # Find the tracker element in the HTML
            tracker_pattern = rf'id="{re.escape(tracker_id)}"'
            match = re.search(tracker_pattern, html_content)
            
            if not match:
                return ""
            
            # Extract surrounding context (1000 chars before and after)
            start = max(0, match.start() - 1000)
            end = min(len(html_content), match.end() + 1000)
            context = html_content[start:end]
            
            # Look for data-name or title attributes in the context
            name_patterns = [
                rf'id="{re.escape(tracker_id)}"[^>]*data-name="([^"]+)"',
                rf'id="{re.escape(tracker_id)}"[^>]*title="([^"]+)"',
                rf'data-name="([^"]+)"[^>]*id="{re.escape(tracker_id)}"',
                rf'title="([^"]+)"[^>]*id="{re.escape(tracker_id)}"',
            ]
            
            for pattern in name_patterns:
                name_match = re.search(pattern, context, re.IGNORECASE)
                if name_match:
                    return name_match.group(1).strip()
            
            # If no explicit name found, try to infer from the tracker ID itself
            return None
            
        except Exception as e:
            logger.error(f"Error inferring display name for {tracker_id}: {e}")
            return ""

    def _infer_from_tracker_id(self, tracker_id: str, tracker_dict: Dict[str, str]) -> str:
        """Infer display name from tracker ID patterns"""
        result = tracker_dict.get(tracker_id)
        if result:
            return result
        # Strip 6-char hex color suffix (e.g. tracker_m_ff0000 -> tracker_m)
        base = re.sub(r'_[0-9a-fA-F]{6}$', '', tracker_id)
        result = tracker_dict.get(base)
        if result:
            return result
        # Resource tokens: resource_COLOR_NUM -> "Resource"
        if re.match(r'^resource_[0-9a-fA-F]{6}_\d+$', tracker_id):
            return 'Resource'
        return f"Unknown ({tracker_id})"

    def _render_bga_log_template(self, template: str, args: Dict[str, Any], tracker_dict: Dict[str, str]) -> str:
        """
        Render a BGA log template by replacing ${...} placeholders with values from args.
        - Supports nested templates like {"log": "...", "args": {...}} (e.g., token_div_count).
        - Maps tracker/counter token names to human-readable via _infer_from_tracker_id.
        """
        def _resolve_value(val: Any, key_name: Optional[str] = None) -> str:
            try:
                if isinstance(val, dict) and 'log' in val and 'args' in val:
                    return self._render_bga_log_template(val.get('log', ''), val.get('args', {}), tracker_dict)
                if isinstance(val, str):
                    # Always check if the value looks like a tracker ID, regardless of key name
                    if val.startswith('tracker_') or val.startswith('counter_'):
                        return self._infer_from_tracker_id(val, tracker_dict)
                    # Check tracker_dict for any known ID (cards, tiles, hexes, etc.)
                    if val in tracker_dict:
                        return tracker_dict[val]
                    # Resolve comma-separated token IDs (e.g. "card_main_3,card_main_43")
                    if ',' in val and key_name in ('token_names', 'token_name'):
                        parts = [v.strip() for v in val.split(',')]
                        resolved = [tracker_dict.get(p, p) for p in parts]
                        return ', '.join(resolved)
                    # Also check based on key name for safety
                    if key_name in ('token_name', 'counter_name'):
                        return self._infer_from_tracker_id(val, tracker_dict)
                    # Format unnamed hex IDs as coordinates
                    hex_match = re.match(r'^hex_(\d+)_(\d+)$', val)
                    if hex_match:
                        return f"Hex {hex_match.group(1)},{hex_match.group(2)}"
                    return val
                return str(val)
            except Exception:
                return str(val)

        def _repl(m: re.Match) -> str:
            name = m.group(1)
            value = None
            if isinstance(args, dict):
                value = args.get(name)
            return _resolve_value(value, name) if value is not None else m.group(0)

        try:
            rendered = re.sub(r'\$\{([^}]+)\}', _repl, template)
            rendered = re.sub(r'\s{2,}', ' ', rendered).strip()
            return rendered
        except Exception:
            return template

    def _track_resources_and_production(self, gamelogs: Dict[str, Any], player_ids: List[str],
                                       tracker_dict: Dict[str, str], card_names_map: Dict[str, str] = None,
                                       color_to_player_id: Dict[str, int] = None,
                                       token_types: Dict[str, Any] = None) -> List[Dict[str, Any]]:
        """Track comprehensive player state through all moves using gamelogs JSON"""
        logger.info(f"Starting comprehensive tracking for {len(player_ids)} players")
        logger.info(f"Tracker dictionary has {len(tracker_dict)} mappings")
        
        try:
            # Initialize tracking data with actual player IDs and only player-specific trackers
            player_data = {}
            
            # Filter tracker_dict to only include player-specific trackers (those with color codes)
            player_specific_trackers = {}
            for tracker_id, display_name in tracker_dict.items():
                # Check if tracker ID ends with a 6-character hex color code
                if re.search(r'_[a-f0-9]{6}$', tracker_id, re.IGNORECASE):
                    player_specific_trackers[tracker_id] = display_name
            
            logger.info(f"Found {len(player_specific_trackers)} player-specific trackers out of {len(tracker_dict)} total")
            
            # Get unique display names from player-specific trackers only
            player_tracker_names = set(player_specific_trackers.values())
            
            # Also filter out global trackers by name patterns
            global_tracker_patterns = [
                'Temperature', 'Oxygen Level', 'Oceans', 'TR',
                'Number of Greenery on Mars', 'Number of owned land', 'Number of Cities',
                'Number of Cities on Mars', 'Pass'
            ]
            
            # Remove global trackers from player tracker names
            filtered_tracker_names = set()
            for tracker_name in player_tracker_names:
                is_global = False
                for pattern in global_tracker_patterns:
                    if pattern in tracker_name:
                        is_global = True
                        break
                if not is_global:
                    filtered_tracker_names.add(tracker_name)
            
            player_tracker_names = filtered_tracker_names
            logger.info(f"After filtering global trackers: {len(player_tracker_names)} player-specific tracker names")
            
            # Build default values from token_types (e.g. Steel Exchange Rate defaults to 2)
            tracker_defaults = {}
            if token_types:
                for tt_key, tt_val in token_types.items():
                    if isinstance(tt_val, dict) and 'state' in tt_val and 'name' in tt_val:
                        display = tt_val['name']
                        if display in player_tracker_names:
                            try:
                                tracker_defaults[display] = int(tt_val['state'])
                            except (ValueError, TypeError):
                                pass

            for player_id in player_ids:
                player_trackers = {name: tracker_defaults.get(name, 0) for name in player_tracker_names}
                player_data[int(player_id)] = player_trackers

            if tracker_defaults:
                logger.info(f"Tracker defaults from token_types: {tracker_defaults}")
            logger.info(f"Initialized {len(player_tracker_names)} player-specific trackers for each player")

            # Track global pile counters
            current_draw_pile = None
            current_discard_pile = None

            # Track resources on cards per player: {player_id: {card_name: {'type': str, 'count': int}}}
            card_resource_counts: Dict[int, Dict[str, Dict[str, Any]]] = {int(pid): {} for pid in player_ids}

            tracking_progression = []
            
            # Get all moves from gamelogs
            data_entries = gamelogs.get('data', {}).get('data', [])
            if not data_entries:
                logger.warning("No data entries found in gamelogs")
                return []
            
            # Find the maximum move ID to determine range
            max_move_id = 0
            for entry in data_entries:
                move_id = entry.get('move_id')
                if move_id and str(move_id).isdigit():
                    max_move_id = max(max_move_id, int(move_id))
            
            logger.info(f"Processing {max_move_id} moves for tracking")
            
            # Process each move
            for move_index in range(1, max_move_id + 1):
                # Find all entries for this move (may span multiple channels)
                move_entries = [e for e in data_entries if isinstance(e, dict) and e.get('move_id') == str(move_index)]

                if not move_entries:
                    # Even if no move entry, store current state to maintain progression
                    tracking_entry = {
                        'move_number': move_index,
                        'data': {pid: dict(data) for pid, data in player_data.items()}
                    }
                    tracking_progression.append(tracking_entry)
                    continue

                # Process all submoves across all entries for this move
                for move_entry in move_entries:
                    submoves = move_entry.get('data', [])
                    for submove in submoves:
                        if not isinstance(submove, dict):
                            continue

                        # Look for counter updates (both counter and counterAsync)
                        args = submove.get('args', {})
                        if not isinstance(args, dict):
                            continue
                        if 'counter_name' in args and 'counter_value' in args:
                            counter_name = args['counter_name']
                            counter_value = args['counter_value']
                            gamelogs_player_id = str(args.get('player_id', ''))

                            # Track global pile counters
                            if counter_name == 'counter_deck_main':
                                try:
                                    current_draw_pile = int(counter_value)
                                except (ValueError, TypeError):
                                    pass
                            elif counter_name == 'counter_discard_main':
                                try:
                                    current_discard_pile = int(counter_value)
                                except (ValueError, TypeError):
                                    pass

                            # Find the display name for this counter
                            display_name = tracker_dict.get(counter_name)
                            if display_name:
                                # Check if this tracker should be excluded
                                global_tracker_patterns = [
                                    'Temperature', 'Oxygen Level', 'Oceans', 'TR',
                                    'Number of Greenery on Mars', 'Number of owned land', 'Number of Cities',
                                    'Number of Cities on Mars', 'Pass'
                                ]

                                is_global = any(pattern in display_name for pattern in global_tracker_patterns)
                                if is_global:
                                    continue

                                # Determine actual player from color suffix in counter_name
                                # The player_id in args is the perspective player, not the owner
                                color_match = re.search(r'_([0-9a-fA-F]{6})$', counter_name)
                                if color_match and color_to_player_id:
                                    actual_player_id = color_to_player_id.get(color_match.group(1).lower())
                                    if actual_player_id is None:
                                        continue
                                else:
                                    try:
                                        actual_player_id = int(gamelogs_player_id)
                                    except (ValueError, TypeError):
                                        continue

                                if actual_player_id in player_data:
                                    try:
                                        validated_value = int(counter_value)
                                    except (ValueError, TypeError):
                                        validated_value = 0

                                    if display_name in player_data[actual_player_id]:
                                        player_data[actual_player_id][display_name] = validated_value

                        # Track resources added/removed from cards
                        if submove.get('type') == 'tokenMoved':
                            tid = str(args.get('token_id', ''))
                            if tid.startswith('resource_'):
                                log_txt = submove.get('log', '')
                                place_id = str(args.get('place_id', ''))
                                card_name = args.get('card_name', '')
                                restype = args.get('restype_name', '')
                                pid_from_args = args.get('player_id')

                                # Determine player from resource token color, then fallback to args
                                res_player_id = None
                                color_match = re.match(r'resource_([0-9a-fA-F]{6})_', tid)
                                if color_match and color_to_player_id:
                                    res_player_id = color_to_player_id.get(color_match.group(1).lower())
                                if res_player_id is None and pid_from_args is not None:
                                    res_player_id = int(pid_from_args)

                                if res_player_id is not None and res_player_id in card_resource_counts:
                                    if 'adds' in log_txt or ('moves' in log_txt and place_id.startswith('card_')):
                                        # Resolve card name if not provided
                                        if not card_name and place_id in (card_names_map or {}):
                                            card_name = card_names_map[place_id]
                                        if not card_name:
                                            card_name = place_id
                                        if card_name not in card_resource_counts[res_player_id]:
                                            card_resource_counts[res_player_id][card_name] = {'type': restype or '', 'count': 0}
                                        card_resource_counts[res_player_id][card_name]['count'] += 1
                                        if restype:
                                            card_resource_counts[res_player_id][card_name]['type'] = restype
                                    elif 'removes' in log_txt:
                                        if not card_name and place_id in (card_names_map or {}):
                                            card_name = card_names_map[place_id]
                                        if card_name:
                                            # Search all players for this card (removals can cross players, e.g. Virus)
                                            for owner_pid, owner_cards in card_resource_counts.items():
                                                if card_name in owner_cards:
                                                    owner_cards[card_name]['count'] = max(0, owner_cards[card_name]['count'] - 1)
                                                    break

                # Store snapshot of current state (includes all previous values + any updates from this move)
                tracking_entry = {
                    'move_number': move_index,
                    'data': {pid: dict(data) for pid, data in player_data.items()},
                    'draw_pile': current_draw_pile,
                    'discard_pile': current_discard_pile,
                    'card_resources': {str(pid): {cn: dict(cd) for cn, cd in cards.items()} for pid, cards in card_resource_counts.items() if cards},
                }
                tracking_progression.append(tracking_entry)
            
            logger.info(f"Completed tracking: {len(tracking_progression)} move snapshots")
            return tracking_progression
            
        except Exception as e:
            logger.error(f"Error in comprehensive tracking: {e}")
            return []

    def _update_game_states_with_tracking(self, moves: List[Move], tracking_progression: List[Dict[str, Any]]):
        """Update GameState objects with comprehensive tracking data"""
        logger.info(f"Updating {len(moves)} game states with tracking data")
        
        # Create a mapping from move number to tracking data
        tracking_by_move = {}
        for entry in tracking_progression:
            move_number = entry['move_number']
            tracking_by_move[move_number] = entry

        # Update each move's game state
        for move in moves:
            if not move.game_state:
                continue

            # Get tracking entry for this move
            tracking_entry = tracking_by_move.get(move.move_number, {})
            move_tracking = tracking_entry.get('data', {})

            # Update draw/discard pile counts
            if tracking_entry.get('draw_pile') is not None:
                move.game_state.draw_pile = tracking_entry['draw_pile']
            if tracking_entry.get('discard_pile') is not None:
                move.game_state.discard_pile = tracking_entry['discard_pile']

            # Inject card_resources into player_vp details
            cr = tracking_entry.get('card_resources')
            if cr and move.game_state.player_vp:
                for pid_str, resources in cr.items():
                    if pid_str in move.game_state.player_vp:
                        pv = move.game_state.player_vp[pid_str]
                        if 'details' not in pv:
                            pv['details'] = {}
                        pv['details']['card_resources'] = resources

            if move_tracking:
                # Store tracking data directly without categorization
                for player_id, player_tracking in move_tracking.items():
                    # Convert player_id to string for consistent key usage
                    player_id_str = str(player_id)
                    
                    # Initialize player trackers if not present
                    if player_id_str not in move.game_state.player_trackers:
                        move.game_state.player_trackers[player_id_str] = {}
                    
                    # Store all tracker values directly
                    for tracker_name, value in player_tracking.items():
                        # Convert value to int and store directly with original tracker name
                        try:
                            validated_value = int(value)
                        except (ValueError, TypeError):
                            validated_value = 0
                        
                        move.game_state.player_trackers[player_id_str][tracker_name] = validated_value
                
                logger.debug(f"Updated game state for move {move.move_number} with tracking data")
        
        logger.info("Completed updating game states with comprehensive tracking data")

    def parse_complete_game_with_elo(self, replay_html: str, table_html: str, table_id: str, player_perspective: str) -> GameData:
        """Parse a complete game with ELO data from both replay and table HTML (legacy method for backward compatibility)"""
        logger.info(f"Starting parsing with ELO data for game {table_id} (legacy method)")
        
        # Parse table metadata first
        game_metadata = self.parse_table_metadata(table_html)
        
        game_data = self.parse_complete_game(
            replay_html=replay_html,
            game_metadata=game_metadata,
            table_id=table_id,
            player_perspective=player_perspective
        )
        
        # Update metadata to indicate ELO data was included (for backward compatibility)
        if game_metadata.players:
            game_data.metadata['elo_data_included'] = len(game_metadata.players) > 0
            game_data.metadata['elo_players_found'] = len(game_metadata.players)
        
        logger.info(f"Legacy parsing with ELO complete for game {table_id}")
        return game_data
    
    def parse_elo_data(self, table_html: str) -> Dict[str, EloData]:
        """
        Parse ELO data from table page HTML
        
        Args:
            table_html: HTML content of the table page
            
        Returns:
            dict: Player name -> EloData mapping
        """
        logger.info("Parsing ELO data from table HTML")
        
        soup = BeautifulSoup(table_html, 'html.parser')
        elo_data = {}
        
        try:
            # Use score-entry sections which contain complete player data
            score_entries = soup.find_all('div', class_='score-entry')
            logger.info(f"Found {len(score_entries)} score entries")
            
            for entry in score_entries:
                player_elo = self._parse_player_from_score_entry(entry)
                if player_elo and 'player_name' in player_elo:
                    player_name = player_elo['player_name']  # Don't pop, keep it in the dict
                    elo_data[player_name] = EloData(**player_elo)
                    logger.info(f"Parsed ELO data for {player_name}")
            
            logger.info(f"Successfully parsed ELO data for {len(elo_data)} players")
            return elo_data
            
        except Exception as e:
            logger.error(f"Error parsing ELO data: {e}")
            return {}
    
    def parse_game_mode(self, table_html: str) -> str:
        
        soup = BeautifulSoup(table_html, 'html.parser')

        span_element = soup.find('span', id='mob_gameoption_201_displayed_value')

        if span_element:

            mode = span_element.get_text().strip()

            return mode
        
        else:
            return "Normal mode" # Default
    
    def _parse_player_from_score_entry(self, score_entry: Tag) -> Optional[Dict[str, Any]]:
        """Parse ELO data for a single player from their score entry section"""
        try:
            player_data = {}
            
            # Extract player name from playername link
            player_link = score_entry.find('a', class_='playername')
            if player_link:
                player_data['player_name'] = player_link.get_text().strip()

            # Extract player ID from href attribute
            href = player_link.get('href')
            if href:
                # Extract ID from "/player?id=86296239" format
                id_match = re.search(r'id=(\d+)', href)
                if id_match:
                    player_data['player_id'] = id_match.group(1)

            # Extract position from rank div
            rank_div = score_entry.find('div', class_='rank')
            if rank_div:
                rank_text = rank_div.get_text().strip()
                # Extract number from "1st", "2nd", "3rd", etc.
                position_match = re.search(r'(\d+)', rank_text)
                if position_match:
                    player_data['position'] = int(position_match.group(1))

            # Extract ELO rating from gamerank_value span
            elo_span = score_entry.find('span', class_='gamerank_value')
            if elo_span:
                elo_text = elo_span.get_text().strip()
                try:
                    player_data['game_rank'] = int(elo_text)
                except ValueError:
                    # In case the ELO text isn't a valid integer
                    player_data['game_rank'] = None
            else:
                player_data['game_rank'] = None

            
            # Find all winpoints in this entry (there should be 2: arena and regular)
            winpoints = score_entry.find_all('div', class_='winpoints')
            
            # Find all newrank in this entry (there should be 2: arena and regular)
            newranks = score_entry.find_all('div', class_='newrank')
            
            # Parse Arena data (first winpoints/newrank pair)
            if len(winpoints) >= 1:
                arena_winpoints_text = winpoints[0].get_text().strip()
                # Extract arena points change
                arena_change_match = re.search(r'([+-]\d+)', arena_winpoints_text)
                if arena_change_match:
                    player_data['arena_points_change'] = int(arena_change_match.group(1))
            
            if len(newranks) >= 1:
                arena_newrank_text = newranks[0].get_text().strip()
                # Extract arena points (current)
                arena_points_match = re.search(r'(\d+)\s*pts', arena_newrank_text)
                if arena_points_match:
                    player_data['arena_points'] = int(arena_points_match.group(1))
            
            # Parse Game ELO data (second winpoints/newrank pair)
            if len(winpoints) >= 2:
                game_winpoints_text = winpoints[1].get_text().strip()
                # Extract game ELO change
                game_change_match = re.search(r'([+-]\d+)', game_winpoints_text)
                if game_change_match:
                    player_data['game_rank_change'] = int(game_change_match.group(1))        
            
            logger.info(f"Extracted ELO data for {player_data['player_name']}: {player_data}")
            return player_data if len(player_data) > 1 else None  # Must have more than just player_name
            
        except Exception as e:
            logger.error(f"Error parsing player from score entry: {e}")
            return None

    def _merge_elo_with_players(self, players: Dict[str, Player], elo_data: Dict[str, EloData]):
        """Merge ELO data into player objects"""
        logger.info(f"Merging ELO data for {len(elo_data)} players")
        
        for player_id, player in players.items():
            # Try to find ELO data by player name
            if player.player_name in elo_data:
                player.elo_data = elo_data[player.player_name]
                logger.info(f"Merged ELO data for player {player.player_name}")
            else:
                logger.warning(f"No ELO data found for player {player.player_name}")

    def parse_replay_with_assignment_metadata(self, replay_html: str, assignment_metadata: Dict[str, Any], table_id: str, player_perspective: str) -> Dict[str, Any]:
        """
        Parse replay HTML combined with assignment metadata (for replay scraping assignments)
        This method uses the ELO data and player info from the assignment instead of scraping table HTML
        
        Args:
            replay_html: HTML content from replay page
            assignment_metadata: Assignment data containing ELO info, player data, etc.
            table_id: BGA table ID
            player_perspective: Player ID whose perspective this is from
            
        Returns:
            dict: Complete parsed game data ready for API upload
        """
        try:
            logger.info(f"Parsing replay with assignment metadata for game {table_id}")
            
            # Convert assignment metadata to GameMetadata format
            game_metadata = self.convert_assignment_to_game_metadata(assignment_metadata)
            
            # Use unified parsing method
            game_data = self.parse_complete_game(
                replay_html=replay_html,
                game_metadata=game_metadata,
                table_id=table_id,
                player_perspective=player_perspective
            )
            
            # Add assignment metadata to game data metadata
            game_data.metadata['assignment_metadata_used'] = True
            game_data.metadata['elo_data_included'] = len(game_metadata.players) > 0 if game_metadata.players else False
            game_data.metadata['elo_players_found'] = len(game_metadata.players) if game_metadata.players else 0
            game_data.metadata['parsed_at'] = datetime.now().isoformat()
            
            # Convert to dictionary format for API upload
            result = self._convert_game_data_to_api_format(game_data, table_id, player_perspective)
            
            logger.info(f"Successfully parsed replay with assignment metadata for game {table_id}")
            return result
            
        except Exception as e:
            logger.error(f"Error parsing replay with assignment metadata for {table_id}: {e}")
            return {}

    def _create_players_from_assignment_metadata(self, elo_data: Dict[str, EloData], assignment_metadata: Dict[str, Any], replay_html: str, table_id: str) -> Dict[str, Player]:
        """Create player objects from assignment metadata"""
        logger.info(f"Creating players from assignment metadata for {len(elo_data)} players")
        
        players = {}
        soup = BeautifulSoup(replay_html, 'html.parser')
        
        # Get VP data for final scores
        vp_data = self._extract_vp_data_from_html(replay_html)
        
        # Get corporations from replay HTML
        corporations = self._extract_corporations(soup)
        
        for player_name, elo_info in elo_data.items():
            player_id = elo_info.player_id
            
            # Get final VP and breakdown
            final_vp = 0
            vp_breakdown = {}
            if player_id in vp_data:
                final_vp = vp_data[player_id].get('total', 0)
                vp_breakdown = vp_data[player_id].get('total_details', {})
            
            # Create player object
            player = Player(
                player_id=player_id,
                player_name=player_name,
                corporation=corporations.get(player_name, 'Unknown'),
                final_vp=final_vp,
                final_tr=vp_breakdown.get('tr', 20),
                vp_breakdown=vp_breakdown,
                cards_played=[],  # Will be populated from moves
                milestones_claimed=[],  # Will be populated from moves
                awards_funded=[],  # Will be populated from moves
                elo_data=elo_info
            )
            
            players[player_id] = player
            logger.info(f"Created player {player_name} with ID {player_id}")
        
        return players

    def _convert_game_data_to_api_format(self, game_data: GameData, table_id: str, player_perspective: str) -> Dict[str, Any]:
        """Convert GameData object to format expected by StoreGameLog API"""
        try:
            # Convert dataclasses to dictionaries for JSON serialization
            def convert_to_dict(obj):
                if hasattr(obj, '__dict__'):
                    return {k: convert_to_dict(v) for k, v in obj.__dict__.items()}
                elif isinstance(obj, list):
                    return [convert_to_dict(item) for item in obj]
                elif isinstance(obj, dict):
                    return {k: convert_to_dict(v) for k, v in obj.items()}
                else:
                    return obj
            
            # Convert the entire game data to dictionary
            result = convert_to_dict(game_data)
            
            # Ensure required fields are present
            result['table_id'] = table_id
            result['player_perspective'] = player_perspective
            
            logger.info(f"Converted game data to API format for {table_id}")
            return result
            
        except Exception as e:
            logger.error(f"Error converting game data to API format: {e}")
            return {}

    def _extract_all_moves_simple(self, soup: BeautifulSoup, name_to_id: Dict[str, str], gamelogs: Dict[str, Any] = None, card_names_map: Dict[str, str] = None, tracker_dict: Dict[str, str] = None) -> List[Move]:
        """Extract all moves, preferring gamelogs JSON with HTML fallback"""
        # Primary path: build all moves from gamelogs JSON
        if gamelogs:
            moves = []
            try:
                data_entries = gamelogs.get('data', {}).get('data', [])
                gl_move_ids: List[int] = []
                for entry in data_entries:
                    mid = entry.get('move_id')
                    if mid and str(mid).isdigit():
                        try:
                            gl_move_ids.append(int(mid))
                        except ValueError:
                            pass
                for move_number in sorted(set(gl_move_ids)):
                    move = self._build_move_from_gamelogs(move_number, name_to_id, gamelogs, card_names_map, tracker_dict)
                    if move:
                        moves.append(move)
            except Exception as e:
                logger.debug(f"Failed extracting moves from gamelogs: {e}")
            if moves:
                return self._apply_takeback_cancellations(moves)
            logger.warning("Gamelogs produced no moves, falling back to HTML parsing")

        # Fallback: parse from HTML move divs
        moves = []
        move_divs = soup.find_all('div', class_='replaylogs_move')
        for move_div in move_divs:
            move = self._parse_single_move_detailed(move_div, name_to_id, gamelogs, card_names_map, tracker_dict)
            if move:
                moves.append(move)

        return self._apply_takeback_cancellations(moves)

    def _is_takeback_move(self, move_number: int, gamelogs: Dict[str, Any]) -> bool:
        """
        Return True if the gamelogs entries for this move_number contain a
        takeback marker (a 'message' or 'undoRestore' entry whose log text
        includes "takes back"). Such moves restore previous state and must
        not be processed as drafts, plays, or other actions.
        """
        try:
            data_entries = gamelogs.get('data', {}).get('data', []) if gamelogs else []
            for entry in data_entries:
                if entry.get('move_id') != str(move_number):
                    continue
                for data_item in entry.get('data', []) or []:
                    if not isinstance(data_item, dict):
                        continue
                    log_txt = data_item.get('log') or ''
                    if isinstance(log_txt, str) and 'takes back' in log_txt.lower():
                        return True
                    if data_item.get('type') == 'undoRestore':
                        return True
        except Exception:
            pass
        return False

    def _apply_takeback_cancellations(self, moves: List[Move]) -> List[Move]:
        """
        Return a new list of moves where, for each takeback move, the
        immediately preceding move by the same player is replaced with a new
        Move marked as cancelled (action data cleared). A BGA "takes back"
        undoes only the player's most recent action, so we only cancel that
        single move. The original Move objects are not mutated — cancelled
        moves are produced via dataclasses.replace.
        """
        cancelled_indices: set = set()
        for i, m in enumerate(moves):
            if getattr(m, 'action_type', None) != 'takeback':
                continue
            for j in range(i - 1, -1, -1):
                prev = moves[j]
                if prev.player_id != m.player_id:
                    break
                if prev.action_type in ('takeback', 'cancelled') or j in cancelled_indices:
                    continue
                cancelled_indices.add(j)
                break

        if not cancelled_indices:
            return moves

        result: List[Move] = []
        for idx, m in enumerate(moves):
            if idx in cancelled_indices:
                result.append(replace(
                    m,
                    action_type='cancelled',
                    description=f"{m.player_name}'s move was cancelled (takeback)",
                    card_played=None,
                    card_drafted=None,
                    tile_placed=None,
                    tile_location=None,
                    card_options=None,
                    cards_kept=None,
                    cards_discarded=None,
                    draft_passed_to=None,
                    reason='cancelled',
                ))
            else:
                result.append(m)
        return result

    def _build_move_from_gamelogs(self, move_number: int, name_to_id: Dict[str, str], gamelogs: Dict[str, Any], card_names_map: Dict[str, str] = None, tracker_dict: Dict[str, str] = None) -> Optional[Move]:
        """
        Construct a Move purely from gamelogs when the HTML does not contain that move block.
        Focuses on draft/draw actions and sets card_options and card_drafted accordingly.
        """
        try:
            # Derive timestamp (HH:MM:SS) from the first entry with a time field for this move
            timestamp = ""
            data_entries = gamelogs.get('data', {}).get('data', [])
            for entry in data_entries:
                if entry.get('move_id') == str(move_number):
                    t = entry.get('time')
                    if t and str(t).isdigit():
                        try:
                            # Convert epoch seconds to HH:MM:SS (UTC)
                            ts = datetime.utcfromtimestamp(int(t))
                            timestamp = ts.strftime("%H:%M:%S")
                            break
                        except Exception:
                            pass
            
            # Determine player based on gamelogs
            player_name, player_id = self._determine_player_from_gamelogs(move_number, gamelogs, name_to_id)
            if not player_name:
                player_name = "Unknown"
            if not player_id:
                player_id = "unknown"

            # Detect takebacks: a 'message' or 'undoRestore' entry whose log says
            # "${player_name} takes back ..." indicates the player undid their previous action.
            # These moves must not be processed as drafts/plays — the tokenMoved/newPrivateState
            # entries that accompany them merely restore prior state.
            if self._is_takeback_move(move_number, gamelogs):
                return Move(
                    move_number=move_number,
                    timestamp=timestamp,
                    player_id=player_id,
                    player_name=player_name,
                    action_type='takeback',
                    description=f"{player_name} takes back their move",
                    reason='takeback',
                )

            # Extract action details using existing helper
            action_type, card_played, tile_placed, tile_location, reason = self._extract_enhanced_action_details(
                move_number, gamelogs, [], ""
            )

            # Map card_played ID to name
            if card_played and card_names_map and card_played in card_names_map:
                card_played = card_names_map[card_played]

            # Map tile_placed and tile_location IDs to names
            if tile_placed and card_names_map and tile_placed in card_names_map:
                tile_placed = card_names_map[tile_placed]
            if tile_location:
                hex_name = card_names_map.get(tile_location) if card_names_map else None
                coords_match = re.match(r'hex_(\d+)_(\d+)', tile_location)
                if hex_name and coords_match:
                    tile_location = f"{hex_name} ({coords_match.group(1)},{coords_match.group(2)})"
                elif hex_name:
                    tile_location = hex_name
                elif coords_match:
                    # Unnamed hex — format as coordinates
                    tile_location = f"Hex {coords_match.group(1)},{coords_match.group(2)}"

            # Build per-player options (draft/draw) and drafted selection
            card_options_map: Optional[Dict[str, List[str]]] = None
            card_drafted_name: Optional[str] = None
            draft_desc_text: Optional[str] = None
            cards_kept_map: Optional[Dict[str, List[str]]] = None
            full_description = ""
            try:
                per_player_draft_ids: Dict[str, List[str]] = {}
                per_player_draw_ids: Dict[str, List[str]] = {}
                per_player_setup_ids: Dict[str, List[str]] = {}
                per_player_kept_ids: Dict[str, List[str]] = {}
                per_player_names: Dict[str, str] = {}
                color_to_pid: Dict[str, str] = {}  # hex color -> player_id (from draft_ place_ids)

                # Aggregate tokenMoved events for this move across all channels
                for entry in data_entries:
                    if entry.get('move_id') != str(move_number):
                        continue
                    entry_data = entry.get('data', [])
                    if not isinstance(entry_data, list):
                        continue
                    for data_item in entry_data:
                        if not isinstance(data_item, dict):
                            continue
                        if data_item.get('type') == 'tokenMoved':
                            args = data_item.get('args', {}) or {}
                            place_tag = args.get('place_id', '') or args.get('place_name', '')
                            pid = str(args.get('player_id')) if args.get('player_id') is not None else "unknown"
                            # Collect options (list of token ids)
                            if isinstance(args.get('list'), list):
                                ids = [tid for tid in args.get('list') if isinstance(tid, str)]
                                if isinstance(place_tag, str) and place_tag.lower().startswith('draft_'):
                                    if ids:
                                        per_player_draft_ids.setdefault(pid, []).extend(ids)
                                    # Map draft color to player_id (e.g. draft_008000 -> pid)
                                    color = place_tag[6:]
                                    if color and pid != "unknown":
                                        color_to_pid[color.lower()] = pid
                                elif isinstance(place_tag, str) and place_tag.lower().startswith('hand_'):
                                    if ids:
                                        per_player_kept_ids.setdefault(pid, []).extend(ids)
                                else:
                                    if ids:
                                        per_player_draw_ids.setdefault(pid, []).extend(ids)
                            # Also capture individual token arrivals to a draft or hand area
                            tok_id = args.get('token_id')
                            if isinstance(place_tag, str) and place_tag.lower().startswith('draft_') and isinstance(tok_id, str):
                                per_player_draft_ids.setdefault(pid, []).append(tok_id)
                                color = place_tag[6:]
                                if color and pid != "unknown":
                                    color_to_pid[color.lower()] = pid
                            if isinstance(place_tag, str) and place_tag.lower().startswith('hand_') and isinstance(tok_id, str):
                                per_player_kept_ids.setdefault(pid, []).append(tok_id)
                            # Track better player names
                            if isinstance(args.get('player_name'), str) and pid != "unknown":
                                per_player_names[pid] = args.get('player_name')
                        # Detect a concrete drafted selection (token_id present)
                        # Only capture the first selection — subsequent ones in the
                        # same move are auto-picks (e.g. last card on the wheel).
                        if card_drafted_name is None and isinstance(data_item, dict) and data_item.get('type') == 'tokenMoved':
                            args = data_item.get('args', {}) or {}
                            token_id = args.get('token_id')
                            if token_id:
                                log_txt = (data_item.get('log') or '').lower()
                                place_tag = str(args.get('place_id', '') or args.get('place_name', '')).lower()
                                sel_pid = str(args.get('player_id')) if args.get('player_id') is not None else "unknown"
                                is_selection = (
                                    ('draft' in log_txt) or
                                    place_tag.startswith('draw_') or
                                    ('keep' in log_txt) or
                                    ('keeps' in log_txt) or
                                    place_tag.startswith('hand_')
                                )
                                if is_selection and sel_pid == str(player_id):
                                    if card_names_map and token_id in card_names_map:
                                        card_drafted_name = card_names_map[token_id]
                                    else:
                                        card_drafted_name = token_id
                                    # Render description using the original template text
                                    try:
                                        log_template = data_item.get('log') or ''
                                        if isinstance(log_template, str) and card_drafted_name:
                                            draft_desc_text = re.sub(r'\$\{token_name\}', card_drafted_name, log_template)
                                    except Exception:
                                        pass
                                    if action_type in ('other', 'draw', 'draft_card'):
                                        action_type = 'draft'
                                    if not reason:
                                        reason = 'draft'
                
                # Merge newPrivateState draft targets into per_player_draft_ids for this move
                # and extract draft pass direction from owner/next_color fields
                draft_passed_to_map: Optional[Dict[str, str]] = None
                try:
                    if gamelogs:
                        for entry in data_entries:
                            if entry.get('move_id') != str(move_number):
                                continue
                            entry_data = entry.get('data', [])
                            if not isinstance(entry_data, list):
                                continue
                            for data_item in entry_data:
                                if isinstance(data_item, dict) and data_item.get('type') == 'newPrivateState':
                                    nps_args = data_item.get('args', {}) or {}
                                    inner = nps_args.get('args', {}) if isinstance(nps_args.get('args', {}), dict) else {}
                                    player_operations = inner.get('player_operations', {})
                                    if isinstance(player_operations, dict):
                                        for pid_key, pop in player_operations.items():
                                            if not isinstance(pop, dict):
                                                continue
                                            operations = pop.get('operations', {})
                                            if isinstance(operations, dict):
                                                for op in operations.values():
                                                    if not isinstance(op, dict):
                                                        continue
                                                    otype = op.get('type') or op.get('typeexpr')
                                                    if otype == 'draft':
                                                        targ = op.get('args', {}).get('target', [])
                                                        if isinstance(targ, list):
                                                            ids = [tid for tid in targ if isinstance(tid, str)]
                                                            if ids:
                                                                per_player_draft_ids.setdefault(str(pid_key), []).extend(ids)
                                                        # Extract draft pass direction
                                                        op_outer_args = op.get('args', {})
                                                        if not isinstance(op_outer_args, dict):
                                                            op_outer_args = {}
                                                        op_inner_args = op_outer_args.get('args', {})
                                                        if not isinstance(op_inner_args, dict):
                                                            op_inner_args = {}
                                                        next_color = op_inner_args.get('next_color', '')
                                                        owner_color = op.get('owner', '')
                                                        if next_color and owner_color:
                                                            from_pid = color_to_pid.get(owner_color.lower())
                                                            to_pid = color_to_pid.get(next_color.lower())
                                                            if from_pid and to_pid:
                                                                if draft_passed_to_map is None:
                                                                    draft_passed_to_map = {}
                                                                draft_passed_to_map[from_pid] = to_pid
                                                    elif otype == 'setuppick':
                                                        # Starting hand options (only project cards)
                                                        targ = op.get('args', {}).get('target', [])
                                                        if isinstance(targ, list):
                                                            ids = [tid for tid in targ if isinstance(tid, str) and tid.startswith('card_main_')]
                                                            if ids:
                                                                per_player_setup_ids.setdefault(str(pid_key), []).extend(ids)
                except Exception:
                    pass

                # When a card play/activation triggers draws as an effect, don't let draw
                # processing override the action_type or description
                is_card_play_with_draw = action_type in ('play_card', 'activate_card') and (per_player_draw_ids or per_player_kept_ids)

                # Build unified card_options from both sources
                if card_names_map and (per_player_draft_ids or per_player_draw_ids or per_player_setup_ids):
                    card_options: Dict[str, List[str]] = {}
                    combined: Dict[str, List[str]] = {}
                    for pid, ids in per_player_draw_ids.items():
                        combined.setdefault(pid, []).extend(list(ids))
                    for pid, ids in per_player_draft_ids.items():
                        combined.setdefault(pid, []).extend(list(ids))
                    for pid, ids in per_player_setup_ids.items():
                        combined.setdefault(pid, []).extend(list(ids))
                    for pid, ids in combined.items():
                        names = [card_names_map.get(tid) for tid in ids]
                        names = [n for n in names if isinstance(n, str) and n.strip()]
                        if names:
                            # dedupe preserving order
                            deduped = list(dict.fromkeys(names))
                            card_options.setdefault(pid, []).extend(deduped)
                    if card_options:
                        card_options_map = card_options
                        # Create a description per player, preferring draft wording if present
                        id_to_name = {mapped_id: pname for pname, mapped_id in name_to_id.items()}
                        parts: List[str] = []
                        source = per_player_draft_ids if per_player_draft_ids else per_player_draw_ids
                        for pid, ids in source.items():
                            names = [card_names_map.get(tid) for tid in ids]
                            names = [n for n in names if isinstance(n, str) and n.strip()]
                            # dedupe for description as well
                            names = list(dict.fromkeys(names))
                            pname = per_player_names.get(pid) or id_to_name.get(pid, f"Player_{pid}")
                            verb = "drafts" if source is per_player_draft_ids else "draws"
                            if len(names) == 1:
                                parts.append(f"{pname} {verb} {names[0]}")
                            elif len(names) > 1:
                                parts.append(f"{pname} {verb} {len(names)} cards: {', '.join(names)}")
                        if not is_card_play_with_draw:
                            full_description = " | ".join(parts)
                        if source and source is per_player_draft_ids and action_type in ('other', 'draw', 'draft_card'):
                            action_type = 'draft'
                        if source and source is per_player_draw_ids and action_type == 'other':
                            action_type = 'draw'
                
                # Map kept cards to names per player
                if card_names_map and per_player_kept_ids:
                    cards_kept = {}
                    for pid, ids in per_player_kept_ids.items():
                        names = [card_names_map.get(tid) for tid in ids]
                        names = [n for n in names if isinstance(n, str) and n.strip()]
                        if names:
                            deduped = list(dict.fromkeys(names))
                            cards_kept[pid] = deduped
                    if cards_kept:
                        cards_kept_map = cards_kept
                        # If we have explicit kept cards this move, build a concise per-player description
                        # Use "draws" for action_type=draw, otherwise use "keeps"
                        try:
                            id_to_name = {mapped_id: pname for pname, mapped_id in name_to_id.items()}
                            parts: List[str] = []
                            for pid, names in cards_kept_map.items():
                                pname = per_player_names.get(pid) or id_to_name.get(pid, f"Player_{pid}")
                                # Choose verb based on action_type
                                verb = "draws" if action_type == "draw" else "keeps"
                                if len(names) == 1:
                                    parts.append(f"{pname} {verb} {names[0]}")
                                else:
                                    parts.append(f"{pname} {verb} {len(names)} cards: {', '.join(names)}")
                            if parts and not is_card_play_with_draw:
                                full_description = " | ".join(parts)
                        except Exception:
                            pass
                # Prefer concrete drafted card description over options summary
                # Do not override a multi-buy summary when cards_kept_map exists
                if card_drafted_name and not cards_kept_map:
                    if isinstance(draft_desc_text, str) and draft_desc_text.strip():
                        full_description = draft_desc_text.strip()
                    else:
                        full_description = f"{player_name} drafts {card_drafted_name}"
                # Build description from gamelog log templates if still empty
                if not full_description:
                    try:
                        # Build an augmented tracker dict that also maps card IDs to names
                        aug_tracker = dict(tracker_dict or {})
                        if card_names_map:
                            aug_tracker.update(card_names_map)
                        desc_parts: List[str] = []
                        for entry in data_entries:
                            if entry.get('move_id') != str(move_number):
                                continue
                            entry_data = entry.get('data', [])
                            if not isinstance(entry_data, list):
                                continue
                            for data_item in entry_data:
                                if not isinstance(data_item, dict):
                                    continue
                                log_t = data_item.get('log', '')
                                if not isinstance(log_t, str) or not log_t.strip():
                                    continue
                                di_args = data_item.get('args', {})
                                if not isinstance(di_args, dict):
                                    continue
                                rendered = self._render_bga_log_template(log_t, di_args, aug_tracker)
                                # Append reason_tr if present
                                rtr = di_args.get('reason_tr')
                                if isinstance(rtr, dict):
                                    reason_rendered = self._render_bga_log_template(rtr.get('log', ''), rtr.get('args', {}), aug_tracker)
                                    if isinstance(reason_rendered, str) and reason_rendered.strip():
                                        rendered = f"{rendered} ({reason_rendered.strip()})"
                                if isinstance(rendered, str) and rendered.strip():
                                    # Strip HTML tags from rendered text
                                    clean = re.sub(r'<[^>]+>', '', rendered).strip()
                                    # Normalize whitespace
                                    clean = re.sub(r'\s+', ' ', clean)
                                    if clean and clean not in desc_parts:
                                        desc_parts.append(clean)
                        if desc_parts:
                            if is_card_play_with_draw:
                                # Reorder: payments and card play first, then effects (draws, etc.)
                                primary = []
                                effects = []
                                for part in desc_parts:
                                    if 'plays card' in part or 'pays' in part:
                                        primary.append(part)
                                    else:
                                        effects.append(part)
                                desc_parts = primary + effects
                            full_description = " | ".join(desc_parts)
                    except Exception:
                        pass

                # If still empty, this is a game state transition with no log text
                if not full_description:
                    if action_type == 'other':
                        action_type = 'game_state_change'
                    full_description = ''

            except Exception as map_err:
                logger.debug(f"Move {move_number}: building from gamelogs mapping failed: {map_err}")
                if action_type == 'other':
                    action_type = 'game_state_change'
                full_description = ''
            
            # Detect discarded cards (sell patents, card effects, etc.)
            # Skip draft/draw moves where "discards" are just cards passed to other players
            cards_discarded_list: Optional[List[str]] = None
            try:
                discarded_card_ids: List[str] = []
                has_draft_pass = False
                revealed_card_ids: set = set()
                for entry in data_entries:
                    if entry.get('move_id') != str(move_number):
                        continue
                    entry_data = entry.get('data', [])
                    if not isinstance(entry_data, list):
                        continue
                    for data_item in entry_data:
                        if not isinstance(data_item, dict):
                            continue
                        if data_item.get('type') == 'tokenMoved':
                            tm_args = data_item.get('args') or {}
                            place_id = str(tm_args.get('place_id', '') or tm_args.get('place_name', ''))
                            token_id = tm_args.get('token_id', '')
                            if place_id.startswith('draft_'):
                                has_draft_pass = True
                            if place_id == 'reveal' and isinstance(token_id, str) and token_id.startswith('card_main_'):
                                revealed_card_ids.add(token_id)
                            if place_id == 'discard_main' and isinstance(token_id, str) and token_id.startswith('card_main_'):
                                if token_id not in revealed_card_ids:
                                    discarded_card_ids.append(token_id)
                if discarded_card_ids and not has_draft_pass:
                    cards_discarded_list = []
                    for cid in discarded_card_ids:
                        if card_names_map and cid in card_names_map:
                            cards_discarded_list.append(card_names_map[cid])
                        else:
                            cards_discarded_list.append(cid)
            except Exception:
                pass

            return Move(
                move_number=move_number,
                timestamp=timestamp,
                player_id=player_id,
                player_name=player_name,
                action_type=action_type,
                description=full_description,
                card_played=card_played,
                card_drafted=card_drafted_name,
                tile_placed=tile_placed,
                tile_location=tile_location,
                card_options=card_options_map,
                cards_kept=cards_kept_map,
                cards_discarded=cards_discarded_list,
                draft_passed_to=draft_passed_to_map,
                reason=reason
            )
        except Exception as e:
            logger.error(f"Error constructing synthetic move {move_number} from gamelogs: {e}")
            return None

    def _build_game_states_simple(self, moves: List[Move], vp_progression: List[Dict[str, Any]], player_ids: List[str], gamelogs: Dict[str, Any] = None, player_perspective: str = None, card_names_map: Dict[str, str] = None) -> List[Move]:
        """Build game states for each move with simple player ID list"""
        # Initialize tracking variables
        current_temp = -30
        current_oxygen = 0
        current_oceans = 0
        current_generation = 1

        # Track milestones, awards, special tiles, hands, and tile counts throughout the game
        current_milestones = {}
        current_awards = {}
        current_special_tiles: Dict[str, Dict[str, str]] = {pid: {} for pid in player_ids}
        current_player_hands: Dict[str, List[str]] = {}

        # Initialize default VP data for all players
        default_vp_data = {}
        for player_id in player_ids:
            default_vp_data[player_id] = {
                "total": 20,
                "total_details": {
                    "tr": 20,
                    "awards": 0,
                    "milestones": 0,
                    "cities": 0,
                    "greeneries": 0,
                    "cards": 0
                }
            }

        # Track the last known VP data to carry forward when no new data is available
        last_vp_data = dict(default_vp_data)

        # Create a mapping from move_number to VP data for proper correlation
        vp_by_move_number = {}
        for vp_entry in vp_progression:
            move_number = vp_entry.get('move_number')
            if move_number:
                # Convert move_number to string for consistent matching
                vp_by_move_number[str(move_number)] = vp_entry.get('vp_data', {})

        logger.info(f"Built VP mapping for {len(vp_by_move_number)} moves")

        # Extract parameter changes and starting player info from gamelogs
        parameter_changes_by_move = {}
        starting_player_by_move = {}  # move_number -> player_id
        if gamelogs:
            parameter_changes_by_move = self._extract_parameter_changes_from_gamelogs(gamelogs)
            logger.info(f"Extracted parameter changes for {len(parameter_changes_by_move)} moves from gamelogs")

            # Build name -> id mapping from moves
            name_to_id_local = {}
            for m in moves:
                if m.player_name and m.player_id:
                    name_to_id_local[m.player_name] = m.player_id

            # Extract starting player per generation
            data_entries = gamelogs.get('data', {}).get('data', [])
            for entry in data_entries:
                if not isinstance(entry, dict):
                    continue
                for item in entry.get('data', []):
                    if not isinstance(item, dict):
                        continue
                    log = item.get('log', '')
                    if 'is starting player' in str(log):
                        args = item.get('args', {})
                        if not isinstance(args, dict):
                            continue
                        pname = args.get('player_name', '')
                        mid = entry.get('move_id')
                        if pname and mid:
                            pid = name_to_id_local.get(pname, pname)
                            try:
                                starting_player_by_move[int(mid)] = pid
                            except (ValueError, TypeError):
                                pass

        current_starting_player = None

        # Process each move and build game state
        for i, move in enumerate(moves):
            # Update starting player if this move has a starting player change
            if move.move_number in starting_player_by_move:
                current_starting_player = starting_player_by_move[move.move_number]

            # Update parameters from gamelogs data
            move_parameter_changes = parameter_changes_by_move.get(move.move_number, {})
            if move_parameter_changes:
                if 'temperature' in move_parameter_changes:
                    current_temp = move_parameter_changes['temperature']
                    logger.debug(f"Move {move.move_number}: Temperature updated to {current_temp}")
                if 'oxygen' in move_parameter_changes:
                    current_oxygen = move_parameter_changes['oxygen']
                    logger.debug(f"Move {move.move_number}: Oxygen updated to {current_oxygen}")
                if 'oceans' in move_parameter_changes:
                    current_oceans = move_parameter_changes['oceans']
                    logger.debug(f"Move {move.move_number}: Oceans updated to {current_oceans}")
                if 'generation' in move_parameter_changes:
                    current_generation = move_parameter_changes['generation']
                    logger.debug(f"Move {move.move_number}: Generation updated to {current_generation}")
            
            # Update milestone and award tracking
            if move.action_type == 'claim_milestone':
                milestone_match = re.search(r'claims milestone (.+?)(?: \||$)', move.description)
                if milestone_match:
                    milestone_name = milestone_match.group(1)
                    current_milestones[milestone_name] = {
                        'claimed_by': move.player_name,
                        'player_id': move.player_id,
                        'move_number': move.move_number,
                        'timestamp': move.timestamp
                    }
            
            if move.action_type == 'fund_award':
                award_match = re.search(r'funds (.+?) award', move.description)
                if award_match:
                    award_name = award_match.group(1)
                    current_awards[award_name] = {
                        'funded_by': move.player_name,
                        'player_id': move.player_id,
                        'move_number': move.move_number,
                        'timestamp': move.timestamp
                    }

            # Back-link marker placements (e.g. Land Claim) to the preceding card play
            if move.tile_location and not move.card_played and not move.tile_placed:
                # This move only has a tile_location from a marker placement.
                # Find the most recent card play by the same player and attach the location.
                for prev_move in reversed(moves[max(0, i-3):i]):
                    if prev_move.card_played and prev_move.player_id == move.player_id:
                        prev_move.tile_location = move.tile_location
                        # Also record in special_tiles
                        if prev_move.player_id in current_special_tiles:
                            current_special_tiles[prev_move.player_id][prev_move.card_played] = move.tile_location
                        logger.debug(f"Move {move.move_number}: Linked marker placement {move.tile_location} back to {prev_move.card_played} (move {prev_move.move_number})")
                        break

            # Track special tile placements (tiles that are not City, Forest, or Ocean)
            if move.action_type == 'place_tile' and move.tile_placed == 'tile':
                tile_name = None
                tile_hex = move.tile_location

                # Try extracting tile name from description ("places X on Y")
                tile_name_match = re.search(r'places (.+?) on (.+?)(?:\s*\(|$)', move.description)
                if tile_name_match:
                    tile_name = tile_name_match.group(1)
                    tile_hex = tile_hex or tile_name_match.group(2)

                # Fallback: check this move's reason or recent prior moves for
                # "immediate effect of X" / "triggered effect of X" to get the card name
                if not tile_name:
                    for check_move in [move] + list(reversed(moves[max(0, i-3):i])):
                        if check_move.reason:
                            effect_match = re.search(r'(?:immediate|triggered) effect of (.+)', check_move.reason)
                            if effect_match:
                                tile_name = effect_match.group(1)
                                break
                        if check_move.card_played and check_move.player_id == move.player_id:
                            tile_name = check_move.card_played
                            break

                if tile_name and tile_hex and move.player_id in current_special_tiles:
                    current_special_tiles[move.player_id][tile_name] = tile_hex

            # Get VP data for this move by matching move_number
            move_vp_data = vp_by_move_number.get(str(move.move_number), {})

            # Ensure VP data is always present
            if move_vp_data:
                # Update last known VP data with new data
                last_vp_data = dict(move_vp_data)
                logger.debug(f"Updated VP data for move {move.move_number}")
            else:
                # Use last known VP data if no new data available
                move_vp_data = dict(last_vp_data)
                logger.debug(f"Using carried-forward VP data for move {move.move_number}")

            # Ensure all players have VP data (fill in missing players with defaults)
            for player_id in player_ids:
                if player_id not in move_vp_data:
                    move_vp_data[player_id] = dict(default_vp_data[player_id])
                    logger.debug(f"Added default VP data for missing player {player_id} in move {move.move_number}")

            # Extract hand for this move (keyed by active player)
            if gamelogs:
                hand_result = self._extract_hand_from_gamelogs(move.move_number, gamelogs, card_names_map)
                if hand_result is not None:
                    hand_pid, hand_cards = hand_result
                    current_player_hands[hand_pid] = hand_cards

            # Supplement hand tracking with move-level card data (fills gaps
            # between gameStateChange events, e.g. cards kept during draft
            # before the player's next action triggers a state update).
            if move.cards_kept:
                for pid, kept_cards in move.cards_kept.items():
                    if pid not in current_player_hands:
                        current_player_hands[pid] = []
                    for card in kept_cards:
                        if card not in current_player_hands[pid]:
                            current_player_hands[pid].append(card)

            if move.card_played and move.player_id in current_player_hands:
                try:
                    current_player_hands[move.player_id].remove(move.card_played)
                except ValueError:
                    pass

            if move.cards_discarded and move.player_id in current_player_hands:
                for card in move.cards_discarded:
                    try:
                        current_player_hands[move.player_id].remove(card)
                    except ValueError:
                        pass

            # Create game state (without resource/production tracking)
            game_state = GameState(
                move_number=move.move_number,
                generation=current_generation,
                temperature=current_temp,
                oxygen=current_oxygen,
                oceans=current_oceans,
                player_vp=move_vp_data,
                milestones=dict(current_milestones),
                awards=dict(current_awards),
                special_tiles={pid: dict(tiles) for pid, tiles in current_special_tiles.items()},
                starting_player=current_starting_player,
                player_hands={pid: list(cards) for pid, cards in current_player_hands.items()}
            )

            move.game_state = game_state

        return moves

    def _determine_winner_and_concession(self, moves: List[Move]) -> Tuple[str, bool]:
        """
        Determine the winner and whether the game was conceded based on final move descriptions.

        - Winner is extracted from: "The end of the game: {NAME} wins!"
        - Concession is detected if any move description contains "concedes the game."
        """
        if not moves:
            return "Unknown", False

        winner = "Unknown"
        conceded = False

        # Scan from the last move backwards to find a conclusive winner line and any concession
        for move in reversed(moves):
            desc = move.description or ""
            # Detect concession anywhere in the final moves
            concession_match = re.search(r'(.+?) concedes (?:the|this) game', desc)
            if concession_match:
                conceded = True
                # Determine winner: use highest VP among non-conceding players
                conceding_player = concession_match.group(1).strip()
                if winner == "Unknown":
                    # Find the last game state with VP data
                    best_vp = -1
                    for m2 in reversed(moves):
                        if m2.game_state and m2.game_state.player_vp:
                            for pid, vp_data in m2.game_state.player_vp.items():
                                pname = None
                                for m3 in moves:
                                    if m3.player_id == pid and m3.player_name:
                                        pname = m3.player_name
                                        break
                                if pname and pname != conceding_player:
                                    total = vp_data.get('total', 0) if isinstance(vp_data, dict) else 0
                                    if total > best_vp:
                                        best_vp = total
                                        winner = pname
                            break
            # Extract winner from end-of-game message variants
            m = re.search(r"(?:The )?[Ee]nd of (?:the )?game\s*:\s*(.+?)\s+wins", desc)
            if m:
                winner = m.group(1).strip()
                break

        # Fallback: extract winner from "X scores N TOTAL VP" in final moves
        if winner == "Unknown":
            player_scores: List[Tuple[str, int, int]] = []  # (name, vp, m€)
            for move in reversed(moves):
                desc = move.description or ""
                parts = desc.split('|')
                # Collect all VP scores and M€ tiebreakers
                tiebreaker_mc: Dict[str, int] = {}
                for part in parts:
                    p = part.strip()
                    tb_match = re.search(r'(\w[\w\s]*?)\s+has\s+(\d+)\s+M', p)
                    if tb_match and 'tiebreaker' in p.lower():
                        tiebreaker_mc[tb_match.group(1).strip()] = int(tb_match.group(2))
                    vp_match = re.search(r'(\w[\w\s]*?)\s+scores\s+(\d+)\s+TOTAL\s+VP', p)
                    if vp_match:
                        pname = vp_match.group(1).strip()
                        total_vp = int(vp_match.group(2))
                        mc = tiebreaker_mc.get(pname, 0)
                        player_scores.append((pname, total_vp, mc))
                if player_scores:
                    break

            if player_scores:
                # Sort by VP descending, then M€ descending
                player_scores.sort(key=lambda x: (x[1], x[2]), reverse=True)
                top = player_scores[0]
                # Check for tie: same VP and same M€ as runner-up
                if len(player_scores) > 1 and top[1] == player_scores[1][1] and top[2] == player_scores[1][2]:
                    winner = "Tie"
                else:
                    winner = top[0]

        return winner, conceded

    def _determine_winner_from_game_states(self, moves_with_states: List[Move], players_info: Dict[str, Player]) -> str:
        """
        Legacy method retained for compatibility. Prefer using _determine_winner_and_concession.
        Falls back to description-based extraction; if unavailable, returns 'Unknown'.
        """
        winner, _ = self._determine_winner_and_concession(moves_with_states)
        return winner

    def export_to_json(self, game_data: GameData, output_path: str, player_perspective: str = None):
        """Export game data to JSON with player perspective folder structure"""
        # If player_perspective is provided, modify the output path to include it
        if player_perspective:
            # Extract directory and filename
            dir_path = os.path.dirname(output_path)
            filename = os.path.basename(output_path)
            
            # Create player perspective subdirectory
            player_dir = os.path.join(dir_path, player_perspective)
            output_path = os.path.join(player_dir, filename)
        
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        
        # Convert dataclasses to dictionaries for JSON serialization
        def convert_to_dict(obj):
            if hasattr(obj, '__dict__'):
                return {k: convert_to_dict(v) for k, v in obj.__dict__.items()}
            elif isinstance(obj, list):
                return [convert_to_dict(item) for item in obj]
            elif isinstance(obj, dict):
                return {k: convert_to_dict(v) for k, v in obj.items()}
            else:
                return obj
        
        data_dict = convert_to_dict(game_data)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(data_dict, f, indent=2, ensure_ascii=False)
